import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import numpy as np
import pandas as pd
from pathlib import Path
import matplotlib.pyplot as plt
from tqdm import tqdm
import time
import music21
import sys
import os
import torch.nn.functional as F

# 导入配置和模型
from config import get_config
from models.hmst_da import HMSTDA
from dataset import MusicDataset

class MusicTransformerLSTM(nn.Module):
    """Music Transformer-LSTM基线模型"""
    def __init__(self, config):
        super().__init__()
        # 修改输入投影层维度
        self.input_proj = nn.Linear(4, config.hidden_dim)  # 从4维投影到hidden_dim
        
        self.transformer = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(
                d_model=config.hidden_dim,
                nhead=config.num_heads,
                dim_feedforward=config.hidden_dim * 4,
                dropout=config.dropout,
                batch_first=True
            ),
            num_layers=config.num_layers
        )
        
        self.lstm = nn.LSTM(
            input_size=config.hidden_dim,
            hidden_size=config.hidden_dim,
            num_layers=2,
            bidirectional=True,
            dropout=config.dropout,
            batch_first=True
        )
        
        # 修改输出投影层维度
        self.output_layer = nn.Linear(config.hidden_dim * 2, 4)  # 从hidden_dim*2投影回4维
    
    def forward(self, x, target_style=None):
        # 投影到高维空间
        x = self.input_proj(x)
        # Transformer编码
        encoded = self.transformer(x)
        # LSTM处理
        lstm_out, _ = self.lstm(encoded)
        # 输出层
        output = self.output_layer(lstm_out)
        return output
    
    def transfer_style(self, source, target_style):
        return self.forward(source, target_style)

class MuseMorphose(nn.Module):
    """MuseMorphose基线模型"""
    def __init__(self, config):
        super().__init__()
        # 修改输入投影层维度
        self.input_proj = nn.Linear(4, config.hidden_dim)  # 从4维投影到hidden_dim
        
        self.encoder = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(
                d_model=config.hidden_dim,
                nhead=config.num_heads,
                dim_feedforward=config.hidden_dim * 4,
                dropout=config.dropout,
                batch_first=True
            ),
            num_layers=config.num_layers
        )
        
        # 修改风格编码器
        self.style_encoder = nn.Sequential(
            nn.Linear(config.hidden_dim, config.hidden_dim),
            nn.ReLU(),
            nn.Dropout(config.dropout),
            nn.Linear(config.hidden_dim, config.hidden_dim)
        )
        
        # 修改解码器的memory_key_padding_mask参数
        self.decoder = nn.TransformerDecoder(
            nn.TransformerDecoderLayer(
                d_model=config.hidden_dim,
                nhead=config.num_heads,
                dim_feedforward=config.hidden_dim * 4,
                dropout=config.dropout,
                batch_first=True
            ),
            num_layers=config.num_layers
        )
        
        # 输出投影层
        self.output_layer = nn.Linear(config.hidden_dim, 4)  # 从hidden_dim投影回4维
    
    def forward(self, x, target_style):
        # 投影到高维空间
        x = self.input_proj(x)  # [batch_size, seq_len, hidden_dim]
        target_style = self.input_proj(target_style)  # [batch_size, seq_len, hidden_dim]
        
        # 编码
        encoded = self.encoder(x)  # [batch_size, seq_len, hidden_dim]
        
        # 风格编码
        style = self.style_encoder(target_style)  # [batch_size, seq_len, hidden_dim]
        
        # 解码（注意维度匹配）
        tgt = encoded  # 使用编码结果作为目标序列
        memory = style  # 使用风格编码作为记忆
        
        # 创建因果mask
        seq_len = encoded.size(1)
        causal_mask = nn.Transformer.generate_square_subsequent_mask(seq_len).to(x.device)
        
        # 解码
        decoded = self.decoder(tgt, memory, tgt_mask=causal_mask)
        
        # 输出投影
        output = self.output_layer(decoded)  # [batch_size, seq_len, 4]
        return output
    
    def transfer_style(self, source, target_style):
        return self.forward(source, target_style)

class SimpleBaseline(nn.Module):
    """简单的基线模型（去掉双路径注意力和理论约束的版本）"""
    def __init__(self, config):
        super().__init__()
        self.model = MusicTransformerLSTM(config)
    
    def transfer_style(self, source, target_style):
        return self.model(source, target_style)

def compute_style_accuracy(output, target):
    """计算风格准确度"""
    try:
        # 确保输入是正确的形状
        if output.dim() == 3:
            output = output.reshape(-1, output.size(-1))
        if target.dim() == 3:
            target = target.reshape(-1, target.size(-1))
            
        # 使用余弦相似度
        cos_sim = F.cosine_similarity(output, target, dim=1)
        # 将相似度映射到[0,1]范围
        style_acc = (cos_sim + 1) / 2
        return style_acc.mean().item()
    except Exception as e:
        print(f"Error in style accuracy: {e}")
        return 0.0

def compute_content_preservation(output, source):
    """计算内容保持度"""
    try:
        # 确保输入是正确的形状
        if output.dim() == 3:
            output = output.reshape(-1, output.size(-1))
        if source.dim() == 3:
            source = source.reshape(-1, source.size(-1))
            
        # 使用余弦相似度并映射到[0,1]范围
        cos_sim = F.cosine_similarity(output, source, dim=1)
        content_pres = (cos_sim + 1) / 2
        return content_pres.mean().item()
    except Exception as e:
        print(f"Error in content preservation: {e}")
        return 0.0

def compute_theory_compliance(output):
    """计算理论合规度"""
    try:
        # 确保输入是正确的形状
        if output.dim() == 3:
            output = output.reshape(-1, output.size(-1))
            
        # 检查音高是否在合理范围内
        pitch_valid = (output[:, 0] >= 0) & (output[:, 0] <= 1)
        
        # 检查时值是否合理
        rhythm_valid = (output[:, 1] >= 0) & (output[:, 1] <= 1)
        
        # 检查力度是否在合理范围内
        velocity_valid = (output[:, -1] >= 0) & (output[:, -1] <= 1)
        
        # 综合评分
        return (pitch_valid.float().mean() + rhythm_valid.float().mean() + velocity_valid.float().mean()).item() / 3
    except Exception as e:
        print(f"Error in theory compliance: {e}")
        return 0.0

def evaluate_model(model, test_loader, device):
    model.eval()
    total_style_acc = 0
    total_content_pres = 0
    total_theory = 0
    count = 0
    
    with torch.no_grad():
        for source, target, _ in test_loader:
            try:
                # 调整输入维度
                source = source.to(device).float()
                target = target.to(device).float()
                
                # 确保输入维度正确
                if source.dim() == 2:
                    source = source.unsqueeze(0)
                if target.dim() == 2:
                    target = target.unsqueeze(0)
                
                # 打印形状以便调试
                print(f"Source shape: {source.shape}")
                print(f"Target shape: {target.shape}")
                
                # 进行风格迁移
                output = model.transfer_style(source, target)
                print(f"Output shape: {output.shape}")
                
                # 计算评估指标
                style_acc = compute_style_accuracy(output, target)
                content_pres = compute_content_preservation(output, source)
                theory_comp = compute_theory_compliance(output)
                
                print(f"Batch scores - Style: {style_acc:.4f}, Content: {content_pres:.4f}, Theory: {theory_comp:.4f}")
                
                if all(x >= 0 for x in [style_acc, content_pres, theory_comp]):
                    total_style_acc += style_acc
                    total_content_pres += content_pres
                    total_theory += theory_comp
                    count += 1
                
            except Exception as e:
                print(f"Error in batch: {e}")
                continue
    
    if count == 0:
        return {
            'style_accuracy': 0,
            'content_preservation': 0,
            'theory_compliance': 0
        }
    
    return {
        'style_accuracy': total_style_acc / count,
        'content_preservation': total_content_pres / count,
        'theory_compliance': total_theory / count
    }

def save_results(results_df, experiment_name=None):
    """
    保存实验结果
    Args:
        results_df: 实验结果DataFrame
        experiment_name: 可选的实验名称
    """
    # 创建results目录（如果不存在）
    os.makedirs('results', exist_ok=True)
    
    # 获取当前时间戳
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    
    # 构建文件名
    if experiment_name:
        csv_filename = f'results/comparison_results_{experiment_name}_{timestamp}_Bach_Rachmaninoff.csv'
        plot_filename = f'results/comparison_plot_{experiment_name}_{timestamp}_Bach_Rachmaninoff.png'
    else:
        csv_filename = f'results/comparison_results_{timestamp}_Bach_Rachmaninoff.csv'
        plot_filename = f'results/comparison_plot_{timestamp}_Bach_Rachmaninoff.png'
    
    # 保存CSV结果
    results_df.to_csv(csv_filename)
    print(f"Results saved to {csv_filename}")
    
    # 创建可视化图表
    plt.figure(figsize=(10, 6))
    results_df.plot(kind='bar')
    plt.title('Model Comparison')
    plt.xlabel('Models')
    plt.ylabel('Scores')
    plt.legend(title='Metrics')
    plt.tight_layout()
    
    # 保存图表
    plt.savefig(plot_filename)
    print(f"Plot saved to {plot_filename}")

def main():
    # 创建配置对象
    config = get_config('HMST-DA')
    
    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    # 初始化所有模型（每个模型使用自己的配置）
    models = {
        'HMST-DA': HMSTDA(config).to(device),
        'MuseMorphose': MuseMorphose(get_config('MuseMorphose')).to(device),
        'MT-LSTM': MusicTransformerLSTM(get_config('MT-LSTM')).to(device)
    }
    
    # Baseline使用HMST-DA的配置，但禁用特殊机制
    baseline_config = get_config('HMST-DA')
    baseline_config.use_dual_attention = False
    baseline_config.use_theory_constraints = False
    models['Baseline'] = SimpleBaseline(baseline_config).to(device)
    
    # 加载HMST-DA权重
    try:
        hmst_path = 'D:\\Files\\Code\\MusicResearch\\results\\best_model_02_10.pth'
        if os.path.exists(hmst_path):
            state_dict = torch.load(hmst_path, map_location=device)
            if isinstance(state_dict, dict) and 'model_state_dict' in state_dict:
                models['HMST-DA'].load_state_dict(state_dict['model_state_dict'])
                print("Successfully loaded HMST-DA model weights")
            else:
                models['HMST-DA'].load_state_dict(state_dict)
                print("Successfully loaded HMST-DA model weights (direct)")
        else:
            print(f"Warning: HMST-DA weights file not found at {hmst_path}")
    except Exception as e:
        print(f"Error loading model weights: {e}")
        print("Continuing with initialized weights...")
    
    # 创建测试数据加载器
    test_dataset = MusicDataset(config, split='test')
    test_loader = DataLoader(
        test_dataset,
        batch_size=1,  # 使用较小的batch size
        shuffle=False,
        num_workers=0,  # 减少worker数量以便调试
        pin_memory=True
    )
    
    # 评估每个模型
    results = {}
    for name, model in models.items():
        print(f"\nEvaluating {name}...")
        model.eval()  # 设置为评估模式
        try:
            metrics = evaluate_model(model, test_loader, device)
            results[name] = metrics
        except Exception as e:
            print(f"Error evaluating {name}: {e}")
            results[name] = {
                'style_accuracy': 0,
                'content_preservation': 0,
                'theory_compliance': 0
            }
    
    # 创建结果DataFrame
    df = pd.DataFrame(results).T
    print("\nComparison Results:")
    print(df)
    
    # 保存结果（可以添加实验名称）
    save_results(df, experiment_name="experiment1")  # 可以根据需要修改实验名称

if __name__ == "__main__":
    main()