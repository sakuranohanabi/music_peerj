import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import numpy as np
import pandas as pd
from pathlib import Path
import matplotlib.pyplot as plt
from tqdm import tqdm
import time
import music21
import sys
import os
import torch.nn.functional as F

# Import configuration and models
from config import get_config
from models.hmst_da import HMSTDA
from dataset import MusicDataset

class MusicTransformerLSTM(nn.Module):
    """
    Music Transformer-LSTM baseline model
    Combines Transformer encoder with LSTM for music style transfer
    """
    def __init__(self, config):
        super().__init__()
        # Project input from 4D to hidden dimension
        self.input_proj = nn.Linear(4, config.hidden_dim)  # From 4D to hidden_dim
        
        # Transformer encoder for feature extraction
        self.transformer = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(
                d_model=config.hidden_dim,
                nhead=config.num_heads,
                dim_feedforward=config.hidden_dim * 4,
                dropout=config.dropout,
                batch_first=True
            ),
            num_layers=config.num_layers
        )
        
        # Bidirectional LSTM for temporal modeling
        self.lstm = nn.LSTM(
            input_size=config.hidden_dim,
            hidden_size=config.hidden_dim,
            num_layers=2,
            bidirectional=True,
            dropout=config.dropout,
            batch_first=True
        )
        
        # Project back to 4D output (pitch, start_time, end_time, velocity)
        self.output_layer = nn.Linear(config.hidden_dim * 2, 4)  # From hidden_dim*2 to 4D
    
    def forward(self, x, target_style=None):
        """
        Forward pass through the model
        Args:
            x: Input tensor [batch_size, seq_len, 4]
            target_style: Target style tensor (optional)
        Returns:
            Output tensor [batch_size, seq_len, 4]
        """
        # Project to high-dimensional space
        x = self.input_proj(x)
        # Transformer encoding
        encoded = self.transformer(x)
        # LSTM processing
        lstm_out, _ = self.lstm(encoded)
        # Output projection
        output = self.output_layer(lstm_out)
        return output
    
    def transfer_style(self, source, target_style):
        """Perform style transfer from source to target style"""
        return self.forward(source, target_style)

class MuseMorphose(nn.Module):
    """
    MuseMorphose baseline model
    Encoder-decoder architecture with style conditioning
    """
    def __init__(self, config):
        super().__init__()
        # Project input from 4D to hidden dimension
        self.input_proj = nn.Linear(4, config.hidden_dim)  # From 4D to hidden_dim
        
        # Transformer encoder for content encoding
        self.encoder = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(
                d_model=config.hidden_dim,
                nhead=config.num_heads,
                dim_feedforward=config.hidden_dim * 4,
                dropout=config.dropout,
                batch_first=True
            ),
            num_layers=config.num_layers
        )
        
        # Style encoder for target style embedding
        self.style_encoder = nn.Sequential(
            nn.Linear(config.hidden_dim, config.hidden_dim),
            nn.ReLU(),
            nn.Dropout(config.dropout),
            nn.Linear(config.hidden_dim, config.hidden_dim)
        )
        
        # Transformer decoder for style-conditioned generation
        self.decoder = nn.TransformerDecoder(
            nn.TransformerDecoderLayer(
                d_model=config.hidden_dim,
                nhead=config.num_heads,
                dim_feedforward=config.hidden_dim * 4,
                dropout=config.dropout,
                batch_first=True
            ),
            num_layers=config.num_layers
        )
        
        # Output projection layer
        self.output_layer = nn.Linear(config.hidden_dim, 4)  # From hidden_dim to 4D
    
    def forward(self, x, target_style):
        """
        Forward pass through the MuseMorphose model
        Args:
            x: Source content tensor [batch_size, seq_len, 4]
            target_style: Target style tensor [batch_size, seq_len, 4]
        Returns:
            Output tensor [batch_size, seq_len, 4]
        """
        # Project to high-dimensional space
        x = self.input_proj(x)  # [batch_size, seq_len, hidden_dim]
        target_style = self.input_proj(target_style)  # [batch_size, seq_len, hidden_dim]
        
        # Content encoding
        encoded = self.encoder(x)  # [batch_size, seq_len, hidden_dim]
        
        # Style encoding
        style = self.style_encoder(target_style)  # [batch_size, seq_len, hidden_dim]
        
        # Decode with style conditioning
        tgt = encoded  # Use encoded content as target sequence
        memory = style  # Use style encoding as memory
        
        # Create causal mask for autoregressive decoding
        seq_len = encoded.size(1)
        causal_mask = nn.Transformer.generate_square_subsequent_mask(seq_len).to(x.device)
        
        # Decode with style conditioning
        decoded = self.decoder(tgt, memory, tgt_mask=causal_mask)
        
        # Output projection
        output = self.output_layer(decoded)  # [batch_size, seq_len, 4]
        return output
    
    def transfer_style(self, source, target_style):
        """Perform style transfer from source to target style"""
        return self.forward(source, target_style)

class SimpleBaseline(nn.Module):
    """
    Simple baseline model (HMST-DA without dual-path attention and theory constraints)
    Used as a control baseline for comparison
    """
    def __init__(self, config):
        super().__init__()
        self.model = MusicTransformerLSTM(config)
    
    def transfer_style(self, source, target_style):
        """Perform style transfer using the simplified model"""
        return self.model(source, target_style)

def compute_style_accuracy(output, target):
    """
    Compute style accuracy using cosine similarity
    Args:
        output: Generated output tensor
        target: Target style tensor
    Returns:
        Style accuracy score (0-1)
    """
    try:
        # Ensure correct tensor shapes
        if output.dim() == 3:
            output = output.reshape(-1, output.size(-1))
        if target.dim() == 3:
            target = target.reshape(-1, target.size(-1))
            
        # Use cosine similarity
        cos_sim = F.cosine_similarity(output, target, dim=1)
        # Map similarity to [0,1] range
        style_acc = (cos_sim + 1) / 2
        return style_acc.mean().item()
    except Exception as e:
        print(f"Error in style accuracy: {e}")
        return 0.0

def compute_content_preservation(output, source):
    """
    Compute content preservation using cosine similarity
    Args:
        output: Generated output tensor
        source: Source content tensor
    Returns:
        Content preservation score (0-1)
    """
    try:
        # Ensure correct tensor shapes
        if output.dim() == 3:
            output = output.reshape(-1, output.size(-1))
        if source.dim() == 3:
            source = source.reshape(-1, source.size(-1))
            
        # Use cosine similarity and map to [0,1] range
        cos_sim = F.cosine_similarity(output, source, dim=1)
        content_pres = (cos_sim + 1) / 2
        return content_pres.mean().item()
    except Exception as e:
        print(f"Error in content preservation: {e}")
        return 0.0

def compute_theory_compliance(output):
    """
    Compute music theory compliance score
    Args:
        output: Generated output tensor
    Returns:
        Theory compliance score (0-1)
    """
    try:
        # Ensure correct tensor shape
        if output.dim() == 3:
            output = output.reshape(-1, output.size(-1))
            
        # Check if pitch is in reasonable range
        pitch_valid = (output[:, 0] >= 0) & (output[:, 0] <= 1)
        
        # Check if rhythm values are reasonable
        rhythm_valid = (output[:, 1] >= 0) & (output[:, 1] <= 1)
        
        # Check if velocity is in reasonable range
        velocity_valid = (output[:, -1] >= 0) & (output[:, -1] <= 1)
        
        # Compute overall score
        return (pitch_valid.float().mean() + rhythm_valid.float().mean() + velocity_valid.float().mean()).item() / 3
    except Exception as e:
        print(f"Error in theory compliance: {e}")
        return 0.0

def evaluate_model(model, test_loader, device):
    """
    Evaluate a model on the test dataset
    Args:
        model: Model to evaluate
        test_loader: DataLoader for test data
        device: Computing device (CPU/GPU)
    Returns:
        Dictionary containing evaluation metrics
    """
    model.eval()
    total_style_acc = 0
    total_content_pres = 0
    total_theory = 0
    count = 0
    
    with torch.no_grad():
        for source, target, _ in test_loader:
            try:
                # Prepare input tensors
                source = source.to(device).float()
                target = target.to(device).float()
                
                # Ensure correct dimensions
                if source.dim() == 2:
                    source = source.unsqueeze(0)
                if target.dim() == 2:
                    target = target.unsqueeze(0)
                
                # Print shapes for debugging
                print(f"Source shape: {source.shape}")
                print(f"Target shape: {target.shape}")
                
                # Perform style transfer
                output = model.transfer_style(source, target)
                print(f"Output shape: {output.shape}")
                
                # Compute evaluation metrics
                style_acc = compute_style_accuracy(output, target)
                content_pres = compute_content_preservation(output, source)
                theory_comp = compute_theory_compliance(output)
                
                print(f"Batch scores - Style: {style_acc:.4f}, Content: {content_pres:.4f}, Theory: {theory_comp:.4f}")
                
                # Accumulate valid scores only
                if all(x >= 0 for x in [style_acc, content_pres, theory_comp]):
                    total_style_acc += style_acc
                    total_content_pres += content_pres
                    total_theory += theory_comp
                    count += 1
                
            except Exception as e:
                print(f"Error in batch: {e}")
                continue
    
    # Return average scores or zeros if no valid batches
    if count == 0:
        return {
            'style_accuracy': 0,
            'content_preservation': 0,
            'theory_compliance': 0
        }
    
    return {
        'style_accuracy': total_style_acc / count,
        'content_preservation': total_content_pres / count,
        'theory_compliance': total_theory / count
    }

def save_results(results_df, experiment_name=None):
    """
    Save experiment results to CSV and create visualization
    Args:
        results_df: DataFrame containing experiment results
        experiment_name: Optional experiment name for file naming
    """
    # Create results directory if it doesn't exist
    os.makedirs('results', exist_ok=True)
    
    # Generate timestamp for unique file naming
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    
    # Construct file names
    if experiment_name:
        csv_filename = f'results/comparison_results_{experiment_name}_{timestamp}_Bach_Rachmaninoff.csv'
        plot_filename = f'results/comparison_plot_{experiment_name}_{timestamp}_Bach_Rachmaninoff.png'
    else:
        csv_filename = f'results/comparison_results_{timestamp}_Bach_Rachmaninoff.csv'
        plot_filename = f'results/comparison_plot_{timestamp}_Bach_Rachmaninoff.png'
    
    # Save CSV results
    results_df.to_csv(csv_filename)
    print(f"Results saved to {csv_filename}")
    
    # Create visualization chart
    plt.figure(figsize=(10, 6))
    results_df.plot(kind='bar')
    plt.title('Model Comparison')
    plt.xlabel('Models')
    plt.ylabel('Scores')
    plt.legend(title='Metrics')
    plt.tight_layout()
    
    # Save chart
    plt.savefig(plot_filename)
    print(f"Plot saved to {plot_filename}")

def main():
    """
    Main function to run model comparison experiments
    """
    # Create configuration object
    config = get_config('HMST-DA')
    
    # Set computing device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    # Initialize all models with their respective configurations
    models = {
        'HMST-DA': HMSTDA(config).to(device),
        'MuseMorphose': MuseMorphose(get_config('MuseMorphose')).to(device),
        'MT-LSTM': MusicTransformerLSTM(get_config('MT-LSTM')).to(device)
    }
    
    # Baseline uses HMST-DA configuration but disables special mechanisms
    baseline_config = get_config('HMST-DA')
    baseline_config.use_dual_attention = False
    baseline_config.use_theory_constraints = False
    models['Baseline'] = SimpleBaseline(baseline_config).to(device)
    
    # Load HMST-DA pre-trained weights
    try:
        hmst_path = 'D:\\Files\\Code\\MusicResearch\\results\\best_model_02_10.pth'
        if os.path.exists(hmst_path):
            state_dict = torch.load(hmst_path, map_location=device)
            if isinstance(state_dict, dict) and 'model_state_dict' in state_dict:
                models['HMST-DA'].load_state_dict(state_dict['model_state_dict'])
                print("Successfully loaded HMST-DA model weights")
            else:
                models['HMST-DA'].load_state_dict(state_dict)
                print("Successfully loaded HMST-DA model weights (direct)")
        else:
            print(f"Warning: HMST-DA weights file not found at {hmst_path}")
    except Exception as e:
        print(f"Error loading model weights: {e}")
        print("Continuing with initialized weights...")
    
    # Create test data loader
    test_dataset = MusicDataset(config, split='test')
    test_loader = DataLoader(
        test_dataset,
        batch_size=1,  # Use small batch size for debugging
        shuffle=False,
        num_workers=0,  # Reduce worker count for debugging
        pin_memory=True
    )
    
    # Evaluate each model
    results = {}
    for name, model in models.items():
        print(f"\nEvaluating {name}...")
        model.eval()  # Set to evaluation mode
        try:
            metrics = evaluate_model(model, test_loader, device)
            results[name] = metrics
        except Exception as e:
            print(f"Error evaluating {name}: {e}")
            results[name] = {
                'style_accuracy': 0,
                'content_preservation': 0,
                'theory_compliance': 0
            }
    
    # Create results DataFrame
    df = pd.DataFrame(results).T
    print("\nComparison Results:")
    print(df)
    
    # Save results with experiment name
    save_results(df, experiment_name="experiment1")  # Can be modified as needed

if __name__ == "__main__":
    main()