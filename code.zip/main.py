import sys
import os
# Add current directory to Python path for module imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from config_1.config import Config
from train import StyleTransferTrainer
import glob
import shutil

def main():
    """
    Main function to execute the music style transfer training and inference pipeline
    
    This function:
    1. Creates configuration for the model
    2. Sets up necessary directories
    3. Initializes and trains the style transfer model
    4. Performs style transfer on a sample MIDI file
    """
    # Create configuration object with default parameters
    config = Config()
    
    # Set dataset path to MAESTRO dataset location
    config.dataset['path'] = 'D:\\Files\\Code\\MusicResearch\\music\\maestro-v3.0.0'  # Ensure this is the correct path
    
    # Create necessary directories for input and output files
    os.makedirs('input', exist_ok=True)   # Directory for input MIDI files
    os.makedirs('output', exist_ok=True)  # Directory for output MIDI files
    
    # Initialize the style transfer trainer with configuration
    trainer = StyleTransferTrainer(config)
    
    # Begin model training process
    trainer.train()
    
    # Find a Bach composition from the dataset and copy it to input folder for demonstration
    dataset_path = config.dataset['path']
    
    # Search for MIDI files with .midi extension
    midi_files = glob.glob(os.path.join(dataset_path, '**/*.midi'), recursive=True)
    
    # If no .midi files found, try searching for .mid extension
    if not midi_files:
        midi_files = glob.glob(os.path.join(dataset_path, '**/*.mid'), recursive=True)
    
    if midi_files:
        # Select the first available MIDI file for style transfer demonstration
        source_midi = midi_files[0]
        input_midi = os.path.join('input', 'source.mid')
        
        # Copy the selected file to input directory
        shutil.copy2(source_midi, input_midi)
        print(f"Copied {source_midi} to {input_midi}")
        
        # Define output path for style-transferred result
        output_midi = 'output/style_transfer_output.mid'
        
        # Perform style transfer on the input MIDI file
        trainer.transfer_style(
            input_midi,    # Source MIDI file path
            output_midi    # Output MIDI file path
        )
    else:
        print("Error: No MIDI files found in the dataset directory")

if __name__ == '__main__':
    # Execute main function when script is run directly
    main()
