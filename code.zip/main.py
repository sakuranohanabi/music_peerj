import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from config_1.config import Config
from train import StyleTransferTrainer
import glob
import shutil

def main():
    # 创建配置
    config = Config()
    
    # 设置数据集路径
    config.dataset['path'] = 'D:\\Files\\Code\\MusicResearch\\music\\maestro-v3.0.0'  # 确保这是正确的路径
    
    # 创建必要的目录
    os.makedirs('input', exist_ok=True)
    os.makedirs('output', exist_ok=True)
    
    # 创建训练器
    trainer = StyleTransferTrainer(config)
    
    # 开始训练
    trainer.train()
    
    # 从数据集中找到一个Bach的作品并复制到input文件夹
    dataset_path = config.dataset['path']
    midi_files = glob.glob(os.path.join(dataset_path, '**/*.midi'), recursive=True)
    
    if not midi_files:
        midi_files = glob.glob(os.path.join(dataset_path, '**/*.mid'), recursive=True)
    
    if midi_files:
        # 选择第一个找到的MIDI文件
        source_midi = midi_files[0]
        input_midi = os.path.join('input', 'source.mid')
        
        # 复制文件到input文件夹
        shutil.copy2(source_midi, input_midi)
        print(f"Copied {source_midi} to {input_midi}")
        
        output_midi = 'output/style_transfer_output.mid'
        
        # 进行风格迁移
        trainer.transfer_style(
            input_midi,
            output_midi
        )
    else:
        print("Error: No MIDI files found in the dataset directory")

if __name__ == '__main__':
    main()
