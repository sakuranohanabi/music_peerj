import numpy as np
import matplotlib.pyplot as plt
import os

def plot_saved_losses(train_losses_path='results/train_losses.npy', 
                     val_losses_path='results/val_losses.npy',
                     save_path='results/losses_visualization_test.png'):
    """
    读取保存的损失数据并重新绘图
    """
    # 读取损失数据
    train_losses = np.load(train_losses_path, allow_pickle=True).item()
    val_losses = np.load(val_losses_path, allow_pickle=True).item()
    
    # 设置默认参数
    plt.rcParams.update({
        'figure.figsize': (20, 8),
        'font.size': 10,
        'axes.labelsize': 12,
        'axes.titlesize': 14,
        'xtick.labelsize': 10,
        'ytick.labelsize': 10,
        # 'grid.linestyle': '--',
        # 'grid.alpha': 0.7,
        'lines.linewidth': 2
    })
    
    # 设置科研配色
    colors = ['#2878B5', '#9AC9DB', '#C82423', '#F8AC8C', '#1B9E77']
    
    # 创建2x5的子图
    fig, axes = plt.subplots(2, 5)
    fig.suptitle('Training and validation losses', fontsize=18, y=1.05)
    
    # 损失类型和对应的标题
    loss_types = ['reconstruction', 'style', 'theory', 'structure', 'coherence']
    titles = ['reconstruction loss', 'style loss', 'theory loss', 
             'structure loss', 'coherence loss']
    
    # 绘制训练损失
    for i, (loss_type, title, color) in enumerate(zip(loss_types, titles, colors)):
        axes[0, i].plot(train_losses[loss_type], 
                      label='Train', linewidth=2, color=color)
        axes[0, i].set_title(f'Training {title}', fontsize=16)
        axes[0, i].set_xlabel('Epoch', fontsize=16)
        axes[0, i].set_ylabel('Loss', fontsize=16)
        # axes[0, i].grid(True, linestyle='--', alpha=0.7)
        axes[0, i].tick_params(labelsize=8)
    
    # 绘制验证损失
    for i, (loss_type, title, color) in enumerate(zip(loss_types, titles, colors)):
        axes[1, i].plot(val_losses[loss_type], 
                      label='Validation', linewidth=2, color=color)
        axes[1, i].set_title(f'Validation {title}', fontsize=16)
        axes[1, i].set_xlabel('Epoch', fontsize=16)
        axes[1, i].set_ylabel('Loss', fontsize=16)
        # axes[1, i].grid(True, linestyle='--', alpha=0.7)
        axes[1, i].tick_params(labelsize=8)
    
    # 调整布局
    plt.tight_layout()
    
    # 创建保存目录（如果不存在）
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    # plt.show()
    # 保存图片
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"Loss visualization has been saved to {save_path}")

if __name__ == "__main__":
    # 使用示例
    plot_saved_losses()