import numpy as np
import matplotlib.pyplot as plt
import os

def plot_saved_losses(train_losses_path='results/train_losses.npy', 
                     val_losses_path='results/val_losses.npy',
                     save_path='results/losses_visualization_test.png'):
    """
    Read saved loss data and create visualization plots
    
    Args:
        train_losses_path: Path to saved training losses (.npy file)
        val_losses_path: Path to saved validation losses (.npy file)
        save_path: Path where the visualization will be saved
    """
    # Load loss data from saved numpy files
    train_losses = np.load(train_losses_path, allow_pickle=True).item()
    val_losses = np.load(val_losses_path, allow_pickle=True).item()
    
    # Set matplotlib parameters for high-quality scientific plots
    plt.rcParams.update({
        'figure.figsize': (12, 20),  # Further increase figure size for larger, more detailed subplots
        'font.size': 30,            # Further increase base font size
        'axes.labelsize': 30,       # Further increase axis label font size
        'axes.titlesize': 30,       # Further increase title font size
        'xtick.labelsize': 30,      # Further increase x-axis tick font size
        'ytick.labelsize': 30,      # Further increase y-axis tick font size
        # 'grid.linestyle': '--',   # Grid line style (commented out)
        # 'grid.alpha': 0.7,        # Grid transparency (commented out)
        'lines.linewidth': 3        # Maintain line thickness
    })
    
    # Set scientific color scheme for professional appearance
    colors = ['#2878B5', '#9AC9DB', '#C82423', '#F8AC8C', '#1B9E77']
    
    # Create 5x2 subplot grid (5 loss types, 2 columns for train/validation)
    fig, axes = plt.subplots(5, 2)
    
    # Define loss types and their corresponding display titles
    loss_types = ['reconstruction', 'style', 'theory', 'structure', 'coherence']
    titles = ['reconstruction loss', 'style loss', 'theory loss', 
             'structure loss', 'coherence loss']
    
    # Plot training and validation losses (one loss type per row, left column: training, right column: validation)
    for i, (loss_type, title, color) in enumerate(zip(loss_types, titles, colors)):
        # Left column: Training losses
        axes[i, 0].plot(train_losses[loss_type], 
                      label='Train', linewidth=3, color=color)
        axes[i, 0].set_title(f'Training {title}', fontsize=22)
        axes[i, 0].tick_params(labelsize=20)  # Further increase coordinate axis number font size
        
        # Right column: Validation losses
        axes[i, 1].plot(val_losses[loss_type], 
                      label='Validation', linewidth=3, color=color)
        axes[i, 1].set_title(f'Validation {title}', fontsize=22)
        axes[i, 1].tick_params(labelsize=20)  # Further increase coordinate axis number font size
    
    # Adjust layout for optimal spacing
    plt.tight_layout()
    # Fine-tune subplot spacing, increase column spacing for better layout with large-sized subplots
    plt.subplots_adjust(hspace=0.3, wspace=0.8)
    
    # Create save directory if it doesn't exist
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    # plt.show()  # Uncomment to display plot interactively
    
    # Save the visualization with high DPI for publication quality
    plt.savefig(save_path, dpi=600, bbox_inches='tight')
    plt.close()  # Close the figure to free memory
    
    print(f"Loss visualization has been saved to {save_path}")

if __name__ == "__main__":
    # Usage example - run the loss visualization function
    plot_saved_losses()