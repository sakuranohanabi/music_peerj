# train.py
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from models.hmst_da import HMSTDA
from data.dataset import MusicStyleDataset
from evaluation.metrics import MusicEvaluator
from utils.music_theory import MusicTheoryChecker
from data.preprocessor import MusicPreprocessor
from tqdm import tqdm
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os

class StyleTransferTrainer:
    """
    Trainer class for Hierarchical Music Style Transfer with Dual-path Attention (HMST-DA)
    
    This class handles:
    - Model initialization and configuration
    - Training loop with multiple loss components
    - Validation and model checkpointing
    - Style transfer inference
    - Loss visualization and logging
    """
    def __init__(self, config):
        """
        Initialize the trainer with configuration
        
        Args:
            config: Configuration object containing model and training parameters
        """
        self.config = config
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Initialize the HMST-DA model
        self.model = HMSTDA(config).to(self.device)
        
        # Initialize data preprocessor for MIDI handling
        self.preprocessor = MusicPreprocessor(config)
        
        # Load training and validation datasets
        self.train_loader, self.val_loader = self.preprocessor.load_dataset()
        
        # Initialize optimizer with gradient clipping and L2 regularization
        self.optimizer = torch.optim.Adam(
            self.model.parameters(),
            lr=config.train['learning_rate'],
            weight_decay=1e-5  # L2 regularization to prevent overfitting
        )
        
        # Add learning rate scheduler for adaptive learning rate adjustment
        self.scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            self.optimizer,
            mode='min',        # Reduce LR when validation loss plateaus
            factor=0.5,        # Multiply LR by 0.5
            patience=5,        # Wait 5 epochs before reducing
            verbose=True       # Print LR changes
        )
        
        # Initialize evaluation components
        self.evaluator = MusicEvaluator()
        self.theory_checker = MusicTheoryChecker()
        
        # Define musical structure constraints for generated music
        self.structure_constraints = {
            'max_notes': 400,        # Maximum number of notes to generate
            'min_pitch': 48,         # Minimum pitch (C3)
            'max_pitch': 84,         # Maximum pitch (C6)
            'min_duration': 0.2,     # Minimum note duration
            'max_duration': 1.2,     # Maximum note duration
            'target_duration': 120.0, # Target total duration in seconds
            'phrase_length': 8,      # Musical phrase length for coherence
        }
        
        # Initialize loss history tracking for visualization
        self.train_losses_history = {
            "reconstruction": [],  # Content preservation loss
            "style": [],          # Style transfer loss
            "theory": [],         # Music theory compliance loss
            "structure": [],      # Musical structure constraint loss
            "coherence": []       # Phrase coherence loss
        }
        self.val_losses_history = {
            "reconstruction": [],
            "style": [],
            "theory": [],
            "structure": [],
            "coherence": []
        }
        
    def compute_loss(self, output, content, style):
        """
        Compute total loss with multiple components for comprehensive training
        
        Args:
            output: Generated music tensor
            content: Source content tensor
            style: Target style tensor
            
        Returns:
            Tuple of (loss_dict, total_loss) where loss_dict contains individual loss components
        """
        # Content reconstruction loss - ensures content preservation
        reconstruction_loss = F.mse_loss(output, content)
        
        # Style consistency loss - ensures style transfer quality
        style_loss = self.evaluator.compute_style_consistency(output, style)
        
        # Music theory compliance loss - ensures musical validity
        theory_loss = self.theory_checker.compute_theory_loss(output)
        
        # Musical structure constraint loss - ensures proper musical structure
        structure_loss = self.compute_structure_loss(output)
        
        # Phrase coherence loss - ensures musical flow and continuity
        coherence_loss = self.compute_coherence_loss(output)
        
        # Organize all loss components
        losses = {
            'reconstruction': reconstruction_loss,
            'style': style_loss,
            'theory': theory_loss,
            'structure': structure_loss,
            'coherence': coherence_loss,
        }
        
        # Print loss components for debugging and monitoring
        print("\nLoss components:")
        for name, loss in losses.items():
            print(f"  {name}: {loss.item():.6f}")
        
        # Compute weighted total loss
        total_loss = (
            reconstruction_loss +
            self.config.train['style_weight'] * style_loss +
            self.config.train['theory_weight'] * theory_loss +
            0.3 * structure_loss +
            0.2 * coherence_loss
        )
        
        return losses, total_loss
    
    def compute_structure_loss(self, output):
        """
        Compute musical structure constraint loss to ensure generated music follows proper structure
        
        Args:
            output: Generated music tensor [batch_size, seq_len, features]
            
        Returns:
            Structure constraint loss tensor
        """
        # Extract musical parameters from output tensor
        pitches = output[:, :, 0] * (self.config.structure['max_pitch'] - self.config.structure['min_pitch']) + self.config.structure['min_pitch']
        durations = output[:, :, 2] - output[:, :, 1]  # Duration = end_time - start_time
        
        # Pitch range constraint loss - ensure pitches are within reasonable range
        pitch_range_loss = F.relu(self.config.structure['min_pitch'] - pitches.min()) + \
                          F.relu(pitches.max() - self.config.structure['max_pitch']) + \
                          0.1 * torch.std(pitches)  # Add pitch distribution regularization
        
        # Duration constraint loss - ensure note durations are reasonable
        duration_loss = F.relu(self.config.structure['min_duration'] - durations.min()) + \
                       F.relu(durations.max() - self.config.structure['max_duration']) + \
                       0.1 * torch.std(durations)  # Add duration distribution regularization
        
        # Total duration constraint - ensure piece has appropriate length
        total_duration = durations.sum() * self.config.structure['target_duration']
        duration_diff = torch.abs(total_duration - self.config.structure['target_duration'])
        total_duration_loss = torch.log1p(duration_diff) + 0.05 * torch.var(durations)  # Add variance constraint
        
        # Note interval regularization - encourage smooth melodic motion
        note_intervals = pitches[:, 1:] - pitches[:, :-1]
        interval_loss = 0.1 * torch.mean(torch.abs(note_intervals))
        
        # Combine all structure constraints
        structure_loss = pitch_range_loss + duration_loss + total_duration_loss + interval_loss
        
        return structure_loss
    
    def compute_coherence_loss(self, output):
        """
        Compute phrase coherence loss to ensure musical continuity and flow
        
        Args:
            output: Generated music tensor [batch_size, seq_len, features]
            
        Returns:
            Coherence loss tensor
        """
        batch_size, seq_len, _ = output.shape
        phrase_length = self.structure_constraints['phrase_length']
        
        # Reshape output into musical phrases
        num_phrases = seq_len // phrase_length
        phrases = output[:, :num_phrases*phrase_length].view(batch_size, num_phrases, phrase_length, -1)
        
        # Compute differences between adjacent phrases for coherence
        phrase_diffs = torch.abs(phrases[:, 1:] - phrases[:, :-1])
        coherence_loss = torch.mean(phrase_diffs)
        
        # Add rhythmic consistency constraint
        rhythm_patterns = output[:, :, 1:3]  # Start and end time features
        rhythm_diffs = torch.abs(rhythm_patterns[:, 1:] - rhythm_patterns[:, :-1])
        rhythm_consistency = torch.mean(rhythm_diffs)
        
        return coherence_loss + 0.5 * rhythm_consistency
    
    def train_epoch(self):
        """
        Train the model for one epoch
        
        Returns:
            Dictionary containing average losses for the epoch
        """
        self.model.train()
        epoch_losses = {
            "reconstruction": 0,
            "style": 0,
            "theory": 0,
            "structure": 0,
            "coherence": 0,
            "total": 0
        }
        num_batches = 0
        
        # Progress bar for training monitoring
        pbar = tqdm(self.train_loader, desc="Training")
        
        for batch_idx, (content, style) in enumerate(pbar):
            try:
                # Move data to device (GPU/CPU)
                content = content.to(self.device)
                style = style.to(self.device)
                
                # Ensure correct tensor dimensions for model input
                if len(content.shape) == 3:
                    content = content.unsqueeze(1)  # [B, 512, 4] -> [B, 1, 512, 4]
                if len(style.shape) == 3:
                    style = style.unsqueeze(1)      # [B, 512, 4] -> [B, 1, 512, 4]
                
                # Forward pass through the model
                output = self.model(content, style)
                
                # Compute all loss components
                losses, total_loss = self.compute_loss(output, content, style)
                
                # Accumulate losses for epoch averaging
                for key in losses:
                    epoch_losses[key] += losses[key].item()
                epoch_losses["total"] += total_loss.item()
                
                # Backpropagation and optimization
                total_loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=0.5)  # Gradient clipping
                self.optimizer.step()
                
                num_batches += 1
                
                # Update progress bar with current loss values
                pbar.set_postfix({
                    'recon': f'{losses["reconstruction"].item():.4f}',
                    'style': f'{losses["style"].item():.4f}',
                    'theory': f'{losses["theory"].item():.4f}',
                    'struct': f'{losses["structure"].item():.4f}',
                    'coher': f'{losses["coherence"].item():.4f}',
                    'total': f'{total_loss.item():.4f}'
                })
                
            except Exception as e:
                print(f"Error in batch {batch_idx}: {str(e)}")
                continue
        
        # Compute average losses for the epoch
        for key in epoch_losses:
            epoch_losses[key] /= max(num_batches, 1)
            
        return epoch_losses

    def validate(self):
        """
        Validate the model on the validation dataset
        
        Returns:
            Dictionary containing average validation losses
        """
        self.model.eval()
        val_losses = {
            "reconstruction": 0,
            "style": 0,
            "theory": 0,
            "structure": 0,
            "coherence": 0,
            "total": 0
        }
        num_batches = 0
        
        with torch.no_grad():  # Disable gradient computation for validation
            for batch_idx, (content, style) in enumerate(self.val_loader):
                try:
                    # Handle tensor dimension adjustments
                    if content.dim() == 4:
                        content = content.squeeze(2)
                    if style.dim() == 4:
                        style = style.squeeze(2)
                        
                    content = content.to(self.device)
                    style = style.to(self.device)
                    
                    # Clamp input values to reasonable range
                    content = torch.clamp(content, 0, 1)
                    style = torch.clamp(style, 0, 1)
                    
                    # Forward pass
                    output = self.model(content, style)
                    
                    # Compute individual loss components
                    reconstruction_loss = F.mse_loss(output, content)
                    style_loss = self.evaluator.compute_style_consistency(output, style)
                    theory_loss = self.theory_checker.compute_theory_loss(output)
                    structure_loss = self.compute_structure_loss(output)
                    coherence_loss = self.compute_coherence_loss(output)
                    
                    # Compute total weighted loss
                    total_loss = (
                        reconstruction_loss +
                        self.config.train['style_weight'] * style_loss +
                        self.config.train['theory_weight'] * theory_loss +
                        0.3 * structure_loss +
                        0.2 * coherence_loss
                    )
                    
                    # Accumulate validation losses
                    val_losses["reconstruction"] += reconstruction_loss.item()
                    val_losses["style"] += style_loss.item()
                    val_losses["theory"] += theory_loss.item()
                    val_losses["structure"] += structure_loss.item()
                    val_losses["coherence"] += coherence_loss.item()
                    val_losses["total"] += total_loss.item()
                    
                    num_batches += 1
                    
                except Exception as e:
                    print(f"Error in validation batch {batch_idx}: {str(e)}")
                    continue
        
        # Compute average validation losses
        for key in val_losses:
            val_losses[key] /= max(num_batches, 1)
            
        return val_losses

    def train(self):
        """
        Main training loop that coordinates training and validation over multiple epochs
        """
        best_val_loss = float('inf')
        
        # Create results directory for saving outputs
        os.makedirs('results', exist_ok=True)
        
        # Training loop over specified number of epochs
        for epoch in range(self.config.train['epochs']):
            print(f'\nEpoch {epoch+1}/{self.config.train["epochs"]}')
            
            # Execute training and validation for current epoch
            train_losses = self.train_epoch()
            val_losses = self.validate()
            
            # Record losses in history for visualization
            for key in self.train_losses_history.keys():
                self.train_losses_history[key].append(train_losses[key])
                self.val_losses_history[key].append(val_losses[key])
            
            # Update learning rate based on validation performance
            self.scheduler.step(val_losses['total'])
            
            # Print detailed training and validation loss information
            print('\nTraining Losses:')
            print(f'  Reconstruction: {train_losses["reconstruction"]:.6f}')
            print(f'  Style: {train_losses["style"]:.6f}')
            print(f'  Theory: {train_losses["theory"]:.6f}')
            print(f'  Structure: {train_losses["structure"]:.6f}')
            print(f'  Coherence: {train_losses["coherence"]:.6f}')
            print(f'  Total: {train_losses["total"]:.6f}')
            
            print('\nValidation Losses:')
            print(f'  Reconstruction: {val_losses["reconstruction"]:.6f}')
            print(f'  Style: {val_losses["style"]:.6f}')
            print(f'  Theory: {val_losses["theory"]:.6f}')
            print(f'  Structure: {val_losses["structure"]:.6f}')
            print(f'  Coherence: {val_losses["coherence"]:.6f}')
            print(f'  Total: {val_losses["total"]:.6f}')
            
            print(f'\nLearning Rate: {self.optimizer.param_groups[0]["lr"]:.6f}')
            
            # Save best model based on validation performance
            if val_losses['total'] < best_val_loss:
                best_val_loss = val_losses['total']
                self.save_model('results/best_model_02_10.pth')
                print(f'New best model saved with validation loss: {best_val_loss:.6f}')
        
        # Generate loss visualization after training completion
        self.plot_losses()
        
        # Save loss history for later analysis
        np.save('results/train_losses.npy', self.train_losses_history)
        np.save('results/val_losses.npy', self.val_losses_history)

    def plot_losses(self):
        """
        Create and save visualization plots for training and validation losses
        """
        # Set matplotlib parameters for high-quality plots
        plt.rcParams.update({
            'figure.figsize': (20, 8),
            'font.size': 10,
            'axes.labelsize': 12,
            'axes.titlesize': 14,
            'xtick.labelsize': 10,
            'ytick.labelsize': 10,
            'grid.linestyle': '--',
            'grid.alpha': 0.7,
            'lines.linewidth': 2
        })
        
        # Set scientific color scheme
        colors = ['#2878B5', '#9AC9DB', '#C82423', '#F8AC8C', '#1B9E77']
        
        # Create 2x5 subplot grid for comprehensive loss visualization
        fig, axes = plt.subplots(2, 5)
        fig.suptitle('Training and Validation Losses', fontsize=16, y=1.05)
        
        # Define loss types and their display titles
        loss_types = ['reconstruction', 'style', 'theory', 'structure', 'coherence']
        titles = ['Reconstruction Loss', 'Style Loss', 'Theory Loss', 
                 'Structure Loss', 'Coherence Loss']
        
        # Plot training losses (top row)
        for i, (loss_type, title, color) in enumerate(zip(loss_types, titles, colors)):
            axes[0, i].plot(self.train_losses_history[loss_type], 
                          label='Train', linewidth=2, color=color)
            axes[0, i].set_title(f'Training {title}', fontsize=12)
            axes[0, i].set_xlabel('Epoch', fontsize=10)
            axes[0, i].set_ylabel('Loss', fontsize=10)
            axes[0, i].grid(True, linestyle='--', alpha=0.7)
            axes[0, i].tick_params(labelsize=8)
        
        # Plot validation losses (bottom row)
        for i, (loss_type, title, color) in enumerate(zip(loss_types, titles, colors)):
            axes[1, i].plot(self.val_losses_history[loss_type], 
                          label='Validation', linewidth=2, color=color)
            axes[1, i].set_title(f'Validation {title}', fontsize=12)
            axes[1, i].set_xlabel('Epoch', fontsize=10)
            axes[1, i].set_ylabel('Loss', fontsize=10)
            axes[1, i].grid(True, linestyle='--', alpha=0.7)
            axes[1, i].tick_params(labelsize=8)
        
        # Adjust layout and save visualization
        plt.tight_layout()
        plt.savefig('results/training_validation_losses.png', dpi=300, bbox_inches='tight')
        plt.close()

    def transfer_style(self, input_midi: str, output_midi: str):
        """
        Perform style transfer on a single MIDI file
        
        Args:
            input_midi: Path to input MIDI file
            output_midi: Path to save the style-transferred output
        """
        self.model.eval()
        
        try:
            # Load and preprocess input MIDI file
            midi_data = self.preprocessor.midi_utils.load_midi(input_midi)
            if midi_data is None:
                print(f"Error: Could not load input MIDI file: {input_midi}")
                return
            
            # Extract musical notes from MIDI data
            notes = self.preprocessor.midi_utils.extract_notes(midi_data)
            
            # Convert notes to tensor representation
            input_tensor = self.preprocessor.midi_utils.notes_to_tensor(notes)
            
            # Ensure correct tensor dimensions [batch_size, seq_len, features]
            if input_tensor.dim() == 2:
                input_tensor = input_tensor.unsqueeze(0)
            
            # Adjust sequence length to match model expectations
            seq_len = self.config.sequence_length
            if input_tensor.size(1) > seq_len:
                input_tensor = input_tensor[:, :seq_len, :]
            elif input_tensor.size(1) < seq_len:
                # Pad sequence to expected length
                pad_size = seq_len - input_tensor.size(1)
                input_tensor = F.pad(input_tensor, (0, 0, 0, pad_size, 0, 0))
            
            input_tensor = input_tensor.to(self.device)
            
            # Get target style sample from training data and adjust dimensions
            style_batch = next(iter(self.train_loader))
            target_style = style_batch[1].to(self.device)
            
            # Ensure target style tensor has correct dimensions
            if target_style.dim() == 4:
                target_style = target_style.squeeze(1)
            if target_style.size(1) > seq_len:
                target_style = target_style[:, :seq_len, :]
            elif target_style.size(1) < seq_len:
                pad_size = seq_len - target_style.size(1)
                target_style = F.pad(target_style, (0, 0, 0, pad_size, 0, 0))
            
            print(f"Input tensor shape: {input_tensor.shape}")
            print(f"Target style tensor shape: {target_style.shape}")
            
            # Perform style transfer inference
            with torch.no_grad():
                output_tensor = self.model(input_tensor, target_style)
            
            # Remove batch dimension for post-processing
            output_tensor = output_tensor.squeeze(0)
            
            # Convert output tensor back to musical notes
            output_notes = self.preprocessor.midi_utils.tensor_to_notes(output_tensor.cpu())
            
            # Save the style-transferred result as MIDI file
            self.preprocessor.midi_utils.save_midi(output_notes, output_midi)
            
            print(f"Successfully generated style transfer MIDI: {output_midi}")
            
        except Exception as e:
            print(f"Error during style transfer: {str(e)}")
            import traceback
            traceback.print_exc()
    
    def save_model(self, path):
        """
        Save model checkpoint including model state and optimizer state
        
        Args:
            path: Path to save the model checkpoint
        """
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
        }, path)
    
    def load_model(self, path):
        """
        Load model checkpoint and restore model and optimizer states
        
        Args:
            path: Path to the saved model checkpoint
        """
        checkpoint = torch.load(path)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])