# train.py
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from models.hmst_da import HMSTDA
from data.dataset import MusicStyleDataset
from evaluation.metrics import MusicEvaluator
from utils.music_theory import MusicTheoryChecker
from data.preprocessor import MusicPreprocessor
from tqdm import tqdm
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os

class StyleTransferTrainer:
    def __init__(self, config):
        self.config = config
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # 初始化模型
        self.model = HMSTDA(config).to(self.device)
        
        # 初始化数据预处理器
        self.preprocessor = MusicPreprocessor(config)
        
        # 加载数据集
        self.train_loader, self.val_loader = self.preprocessor.load_dataset()
        
        # 使用梯度裁剪的优化器
        self.optimizer = torch.optim.Adam(
            self.model.parameters(),
            lr=config.train['learning_rate'],
            weight_decay=1e-5  # 添加L2正则化
        )
        
        # 添加学习率调度器
        self.scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            self.optimizer,
            mode='min',
            factor=0.5,
            patience=5,
            verbose=True
        )
        
        # 初始化评估器
        self.evaluator = MusicEvaluator()
        self.theory_checker = MusicTheoryChecker()
        
        # 添加音乐结构约束
        self.structure_constraints = {
            'max_notes': 400,  # 限制最大音符数量
            'min_pitch': 48,   # C3
            'max_pitch': 84,   # C6
            'min_duration': 0.2,
            'max_duration': 1.2,
            'target_duration': 120.0,  # 目标总时长(秒)
            'phrase_length': 8,  # 短语长度
        }
        
        # 添加损失记录器
        self.train_losses_history = {
            "reconstruction": [],
            "style": [],
            "theory": [],
            "structure": [],
            "coherence": []
        }
        self.val_losses_history = {
            "reconstruction": [],
            "style": [],
            "theory": [],
            "structure": [],
            "coherence": []
        }
        
    def compute_loss(self, output, content, style):
        """计算总损失"""
        # 重建损失
        reconstruction_loss = F.mse_loss(output, content)
        
        # 风格损失
        style_loss = self.evaluator.compute_style_consistency(output, style)
        
        # 理论损失
        theory_loss = self.theory_checker.compute_theory_loss(output)
        
        # 结构损失
        structure_loss = self.compute_structure_loss(output)
        
        # 连贯性损失
        coherence_loss = self.compute_coherence_loss(output)
        
        # 确保所有损失都被正确计算
        losses = {
            'reconstruction': reconstruction_loss,
            'style': style_loss,
            'theory': theory_loss,
            'structure': structure_loss,
            'coherence': coherence_loss,
        }
        
        # 添加调试信息
        print("\nLoss components:")
        for name, loss in losses.items():
            print(f"  {name}: {loss.item():.6f}")
        
        # 计算总损失
        total_loss = (
            reconstruction_loss +
            self.config.train['style_weight'] * style_loss +
            self.config.train['theory_weight'] * theory_loss +
            0.3 * structure_loss +
            0.2 * coherence_loss
        )
        
        return losses, total_loss
    
    def compute_structure_loss(self, output):
        """计算音乐结构约束损失"""
        # 提取音符参数
        pitches = output[:, :, 0] * (self.config.structure['max_pitch'] - self.config.structure['min_pitch']) + self.config.structure['min_pitch']
        durations = output[:, :, 2] - output[:, :, 1]
        
        # 计算音高范围损失
        pitch_range_loss = F.relu(self.config.structure['min_pitch'] - pitches.min()) + \
                          F.relu(pitches.max() - self.config.structure['max_pitch']) + \
                          0.1 * torch.std(pitches)  # 添加音高分布的正则化项
        
        # 计算持续时间约束损失
        duration_loss = F.relu(self.config.structure['min_duration'] - durations.min()) + \
                       F.relu(durations.max() - self.config.structure['max_duration']) + \
                       0.1 * torch.std(durations)  # 添加持续时间分布的正则化项
        
        # 计算总时长约束
        total_duration = durations.sum() * self.config.structure['target_duration']
        duration_diff = torch.abs(total_duration - self.config.structure['target_duration'])
        total_duration_loss = torch.log1p(duration_diff) + 0.05 * torch.var(durations)  # 添加变异度约束
        
        # 添加音符间隔的正则化
        note_intervals = pitches[:, 1:] - pitches[:, :-1]
        interval_loss = 0.1 * torch.mean(torch.abs(note_intervals))
        
        structure_loss = pitch_range_loss + duration_loss + total_duration_loss + interval_loss
        
        return structure_loss
    
    def compute_coherence_loss(self, output):
        """计算短语连贯性损失"""
        batch_size, seq_len, _ = output.shape
        phrase_length = self.structure_constraints['phrase_length']
        
        # 重塑输出为短语
        num_phrases = seq_len // phrase_length
        phrases = output[:, :num_phrases*phrase_length].view(batch_size, num_phrases, phrase_length, -1)
        
        # 计算相邻短语之间的差异
        phrase_diffs = torch.abs(phrases[:, 1:] - phrases[:, :-1])
        coherence_loss = torch.mean(phrase_diffs)
        
        # 添加节奏一致性约束
        rhythm_patterns = output[:, :, 1:3]  # start和end时间
        rhythm_diffs = torch.abs(rhythm_patterns[:, 1:] - rhythm_patterns[:, :-1])
        rhythm_consistency = torch.mean(rhythm_diffs)
        
        return coherence_loss + 0.5 * rhythm_consistency
    
    def train_epoch(self):
        """训练一个epoch"""
        self.model.train()
        epoch_losses = {
            "reconstruction": 0,
            "style": 0,
            "theory": 0,
            "structure": 0,
            "coherence": 0,
            "total": 0
        }
        num_batches = 0
        
        pbar = tqdm(self.train_loader, desc="Training")
        
        for batch_idx, (content, style) in enumerate(pbar):
            try:
                content = content.to(self.device)
                style = style.to(self.device)
                
                # 确保维度匹配
                if len(content.shape) == 3:
                    content = content.unsqueeze(1)  # [B, 512, 4] -> [B, 1, 512, 4]
                if len(style.shape) == 3:
                    style = style.unsqueeze(1)      # [B, 512, 4] -> [B, 1, 512, 4]
                
                output = self.model(content, style)
                losses, total_loss = self.compute_loss(output, content, style)
                
                # 更新损失记录
                for key in losses:
                    epoch_losses[key] += losses[key].item()
                epoch_losses["total"] += total_loss.item()
                
                # 反向传播
                total_loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=0.5)
                self.optimizer.step()
                
                num_batches += 1
                
                # 更新进度条
                pbar.set_postfix({
                    'recon': f'{losses["reconstruction"].item():.4f}',
                    'style': f'{losses["style"].item():.4f}',
                    'theory': f'{losses["theory"].item():.4f}',
                    'struct': f'{losses["structure"].item():.4f}',
                    'coher': f'{losses["coherence"].item():.4f}',
                    'total': f'{total_loss.item():.4f}'
                })
                
            except Exception as e:
                print(f"Error in batch {batch_idx}: {str(e)}")
                continue
        
        # 计算平均损失
        for key in epoch_losses:
            epoch_losses[key] /= max(num_batches, 1)
            
        return epoch_losses

    def validate(self):
        """验证模型"""
        self.model.eval()
        val_losses = {
            "reconstruction": 0,
            "style": 0,
            "theory": 0,
            "structure": 0,
            "coherence": 0,
            "total": 0
        }
        num_batches = 0
        
        with torch.no_grad():
            for batch_idx, (content, style) in enumerate(self.val_loader):
                try:
                    if content.dim() == 4:
                        content = content.squeeze(2)
                    if style.dim() == 4:
                        style = style.squeeze(2)
                        
                    content = content.to(self.device)
                    style = style.to(self.device)
                    
                    # 确保输入在合理范围内
                    content = torch.clamp(content, 0, 1)
                    style = torch.clamp(style, 0, 1)
                    
                    output = self.model(content, style)
                    
                    # 计算各个损失组件
                    reconstruction_loss = F.mse_loss(output, content)
                    style_loss = self.evaluator.compute_style_consistency(output, style)
                    theory_loss = self.theory_checker.compute_theory_loss(output)
                    structure_loss = self.compute_structure_loss(output)
                    coherence_loss = self.compute_coherence_loss(output)
                    
                    total_loss = (
                        reconstruction_loss +
                        self.config.train['style_weight'] * style_loss +
                        self.config.train['theory_weight'] * theory_loss +
                        0.3 * structure_loss +
                        0.2 * coherence_loss
                    )
                    
                    # 累加损失
                    val_losses["reconstruction"] += reconstruction_loss.item()
                    val_losses["style"] += style_loss.item()
                    val_losses["theory"] += theory_loss.item()
                    val_losses["structure"] += structure_loss.item()
                    val_losses["coherence"] += coherence_loss.item()
                    val_losses["total"] += total_loss.item()
                    
                    num_batches += 1
                    
                except Exception as e:
                    print(f"Error in validation batch {batch_idx}: {str(e)}")
                    continue
        
        # 计算平均损失
        for key in val_losses:
            val_losses[key] /= max(num_batches, 1)
            
        return val_losses

    def train(self):
        """训练模型"""
        best_val_loss = float('inf')
        
        # 创建保存目录
        os.makedirs('results', exist_ok=True)
        
        for epoch in range(self.config.train['epochs']):
            print(f'\nEpoch {epoch+1}/{self.config.train["epochs"]}')
            
            # 训练和验证
            train_losses = self.train_epoch()
            val_losses = self.validate()
            
            # 记录损失
            for key in self.train_losses_history.keys():
                self.train_losses_history[key].append(train_losses[key])
                self.val_losses_history[key].append(val_losses[key])
            
            # 更新学习率
            self.scheduler.step(val_losses['total'])
            
            # 打印详细的训练和验证损失
            print('\nTraining Losses:')
            print(f'  Reconstruction: {train_losses["reconstruction"]:.6f}')
            print(f'  Style: {train_losses["style"]:.6f}')
            print(f'  Theory: {train_losses["theory"]:.6f}')
            print(f'  Structure: {train_losses["structure"]:.6f}')
            print(f'  Coherence: {train_losses["coherence"]:.6f}')
            print(f'  Total: {train_losses["total"]:.6f}')
            
            print('\nValidation Losses:')
            print(f'  Reconstruction: {val_losses["reconstruction"]:.6f}')
            print(f'  Style: {val_losses["style"]:.6f}')
            print(f'  Theory: {val_losses["theory"]:.6f}')
            print(f'  Structure: {val_losses["structure"]:.6f}')
            print(f'  Coherence: {val_losses["coherence"]:.6f}')
            print(f'  Total: {val_losses["total"]:.6f}')
            
            print(f'\nLearning Rate: {self.optimizer.param_groups[0]["lr"]:.6f}')
            
            # 保存最佳模型
            if val_losses['total'] < best_val_loss:
                best_val_loss = val_losses['total']
                self.save_model('results/best_model_02_10.pth')
                print(f'New best model saved with validation loss: {best_val_loss:.6f}')
        
        # 训练结束后绘制损失图
        self.plot_losses()
        
        # 保存损失历史
        np.save('results/train_losses.npy', self.train_losses_history)
        np.save('results/val_losses.npy', self.val_losses_history)

    def plot_losses(self):
        """绘制训练和验证损失图"""
        # 设置默认参数
        plt.rcParams.update({
            'figure.figsize': (20, 8),
            'font.size': 10,
            'axes.labelsize': 12,
            'axes.titlesize': 14,
            'xtick.labelsize': 10,
            'ytick.labelsize': 10,
            'grid.linestyle': '--',
            'grid.alpha': 0.7,
            'lines.linewidth': 2
        })
        
        # 设置科研配色
        colors = ['#2878B5', '#9AC9DB', '#C82423', '#F8AC8C', '#1B9E77']
        
        # 创建2x5的子图
        fig, axes = plt.subplots(2, 5)
        fig.suptitle('Training and Validation Losses', fontsize=16, y=1.05)
        
        # 损失类型和对应的标题
        loss_types = ['reconstruction', 'style', 'theory', 'structure', 'coherence']
        titles = ['Reconstruction Loss', 'Style Loss', 'Theory Loss', 
                 'Structure Loss', 'Coherence Loss']
        
        # 绘制训练损失
        for i, (loss_type, title, color) in enumerate(zip(loss_types, titles, colors)):
            axes[0, i].plot(self.train_losses_history[loss_type], 
                          label='Train', linewidth=2, color=color)
            axes[0, i].set_title(f'Training {title}', fontsize=12)
            axes[0, i].set_xlabel('Epoch', fontsize=10)
            axes[0, i].set_ylabel('Loss', fontsize=10)
            axes[0, i].grid(True, linestyle='--', alpha=0.7)
            axes[0, i].tick_params(labelsize=8)
        
        # 绘制验证损失
        for i, (loss_type, title, color) in enumerate(zip(loss_types, titles, colors)):
            axes[1, i].plot(self.val_losses_history[loss_type], 
                          label='Validation', linewidth=2, color=color)
            axes[1, i].set_title(f'Validation {title}', fontsize=12)
            axes[1, i].set_xlabel('Epoch', fontsize=10)
            axes[1, i].set_ylabel('Loss', fontsize=10)
            axes[1, i].grid(True, linestyle='--', alpha=0.7)
            axes[1, i].tick_params(labelsize=8)
        
        # 调整布局
        plt.tight_layout()
        
        # 保存图片
        plt.savefig('results/training_validation_losses.png', dpi=300, bbox_inches='tight')
        plt.close()

    def transfer_style(self, input_midi: str, output_midi: str):
        """对单个MIDI文件进行风格迁移"""
        self.model.eval()
        
        try:
            # 加载输入MIDI
            midi_data = self.preprocessor.midi_utils.load_midi(input_midi)
            if midi_data is None:
                print(f"Error: Could not load input MIDI file: {input_midi}")
                return
            
            # 提取音符
            notes = self.preprocessor.midi_utils.extract_notes(midi_data)
            
            # 转换为张量
            input_tensor = self.preprocessor.midi_utils.notes_to_tensor(notes)
            
            # 确保输入张量维度正确 [batch_size, seq_len, features]
            if input_tensor.dim() == 2:
                input_tensor = input_tensor.unsqueeze(0)
            
            # 调整序列长度为模型期望的长度
            seq_len = self.config.sequence_length
            if input_tensor.size(1) > seq_len:
                input_tensor = input_tensor[:, :seq_len, :]
            elif input_tensor.size(1) < seq_len:
                # 填充到期望长度
                pad_size = seq_len - input_tensor.size(1)
                input_tensor = F.pad(input_tensor, (0, 0, 0, pad_size, 0, 0))
            
            input_tensor = input_tensor.to(self.device)
            
            # 从训练集中获取目标风格样本并调整其维度
            style_batch = next(iter(self.train_loader))
            target_style = style_batch[1].to(self.device)
            
            # 确保目标风格张量维度正确
            if target_style.dim() == 4:
                target_style = target_style.squeeze(1)
            if target_style.size(1) > seq_len:
                target_style = target_style[:, :seq_len, :]
            elif target_style.size(1) < seq_len:
                pad_size = seq_len - target_style.size(1)
                target_style = F.pad(target_style, (0, 0, 0, pad_size, 0, 0))
            
            print(f"Input tensor shape: {input_tensor.shape}")
            print(f"Target style tensor shape: {target_style.shape}")
            
            # 风格迁移
            with torch.no_grad():
                output_tensor = self.model(input_tensor, target_style)
            
            # 移除批次维度
            output_tensor = output_tensor.squeeze(0)
            
            # 转换回音符列表
            output_notes = self.preprocessor.midi_utils.tensor_to_notes(output_tensor.cpu())
            
            # 保存为MIDI文件
            self.preprocessor.midi_utils.save_midi(output_notes, output_midi)
            
            print(f"Successfully generated style transfer MIDI: {output_midi}")
            
        except Exception as e:
            print(f"Error during style transfer: {str(e)}")
            import traceback
            traceback.print_exc()
    
    def save_model(self, path):
        """保存模型"""
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
        }, path)
    
    def load_model(self, path):
        """加载模型"""
        checkpoint = torch.load(path)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])