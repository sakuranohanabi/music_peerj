import pandas as pd
from pathlib import Path

def verify_maestro():
    """
    Verify the MAESTRO dataset integrity and provide composer statistics
    
    This function:
    1. Checks if the MAESTRO CSV metadata file exists
    2. Lists all available composers and their piece counts
    3. Reports specific composer statistics (Bach, Chopin)
    4. Verifies that all referenced MIDI files exist on disk
    """
    # Define MAESTRO dataset path
    dataset_path = Path('D:\\Files\\Code\\MusicResearch\\music\\maestro-v3.0.0')
    
    # Check if the CSV metadata file exists
    csv_path = dataset_path / 'maestro-v3.0.0.csv'
    if not csv_path.exists():
        print("Error: maestro-v3.0.0.csv file not found")
        return False
        
    # Load metadata from CSV file
    df = pd.read_csv(csv_path)
    
    # Display available composers and their piece counts
    composers = df['canonical_composer'].unique()
    print("\nAvailable composers list:")
    for composer in sorted(composers):
        piece_count = len(df[df['canonical_composer'] == composer])
        print(f"- {composer}: {piece_count} pieces")
    
    # Check specific composer statistics for style transfer experiments
    bach_works = df[df['canonical_composer'] == 'Bach, Johann Sebastian']
    chopin_works = df[df['canonical_composer'] == 'Chopin, Frédéric']
    
    print(f"\nBach works count: {len(bach_works)}")
    print(f"Chopin works count: {len(chopin_works)}")
    
    # Verify that all MIDI files referenced in metadata actually exist
    print("\nVerifying MIDI files...")
    missing_files = 0
    for _, row in df.iterrows():
        midi_path = dataset_path / row['midi_filename']
        if not midi_path.exists():
            print(f"Missing file: {midi_path}")
            missing_files += 1
    
    # Report verification results
    if missing_files == 0:
        print("All MIDI files exist!")
    else:
        print(f"Warning: {missing_files} MIDI files are missing")

if __name__ == '__main__':
    # Execute dataset verification when script is run directly
    verify_maestro()
