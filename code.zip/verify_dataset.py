import pandas as pd
from pathlib import Path

def verify_maestro():
    # 数据集路径
    dataset_path = Path('D:\\Files\\Code\\MusicResearch\\music\\maestro-v3.0.0')
    
    # 检查CSV文件
    csv_path = dataset_path / 'maestro-v3.0.0.csv'
    if not csv_path.exists():
        print("错误：找不到maestro-v3.0.0.csv文件")
        return False
        
    # 加载元数据
    df = pd.read_csv(csv_path)
    
    # 查看可用的作曲家
    composers = df['canonical_composer'].unique()
    print("\n可用的作曲家列表：")
    for composer in sorted(composers):
        piece_count = len(df[df['canonical_composer'] == composer])
        print(f"- {composer}: {piece_count}作品")
    
    # 检查特定作曲家的作品数量
    bach_works = df[df['canonical_composer'] == 'Bach, Johann Sebastian']
    chopin_works = df[df['canonical_composer'] == 'Chopin, Frédéric']
    
    print(f"\nBach作品数量: {len(bach_works)}")
    print(f"Chopin作品数量: {len(chopin_works)}")
    
    # 验证MIDI文件是否存在
    print("\n验证MIDI文件...")
    missing_files = 0
    for _, row in df.iterrows():
        midi_path = dataset_path / row['midi_filename']
        if not midi_path.exists():
            print(f"找不到文件: {midi_path}")
            missing_files += 1
    
    if missing_files == 0:
        print("所有MIDI文件都存在！")
    else:
        print(f"警告：有{missing_files}个MIDI文件缺失")

if __name__ == '__main__':
    verify_maestro()
