class BaseConfig:
    """基础配置类"""
    def __init__(self):
        # 通用配置
        self.batch_size = 16
        self.max_seq_len = 1024
        self.vocab_size = 128
        self.input_dim = 128
        self.output_dim = 128
        self.hidden_dim = 512
        self.num_layers = 6
        self.num_heads = 8
        self.dropout = 0.1
        self.learning_rate = 0.0001
        
        # 添加训练相关配置
        self.train = {
            'batch_size': 16,
            'epochs': 100,
            'learning_rate': 5e-5,
            'early_stopping_patience': 10,
            'max_grad_norm': 0.5
        }
        
        # 添加路径配置
        self.save_dir = 'checkpoints'
        self.result_dir = 'results'
        self.num_workers = 4

class HMSTConfig(BaseConfig):
    """HMST-DA模型配置"""
    def __init__(self):
        super().__init__()
        # 修改为与预训练模型匹配的维度
        self.hidden_dim = 256  # 从512改为256
        self.num_heads = 8
        self.num_layers = 3    # 从6改为3
        self.ff_size = 1024    # 从2048改为1024
        self.dropout = 0.1
        self.style_dim = 256
        
        # 输入输出维度
        self.input_dim = 4     # 从128改为4
        self.output_dim = 4    # 从128改为4
        
        # 特殊机制配置
        self.use_dual_attention = True
        self.use_theory_constraints = True

class MuseMorphoseConfig(BaseConfig):
    """MuseMorphose基线模型配置"""
    def __init__(self):
        super().__init__()
        self.hidden_dim = 256
        self.num_heads = 4
        self.num_layers = 4
        self.ff_size = 1024
        self.dropout = 0.1
        self.style_dim = 128

class MTLSTMConfig(BaseConfig):
    """Music Transformer-LSTM基线模型配置"""
    def __init__(self):
        super().__init__()
        self.hidden_dim = 256
        self.num_heads = 4
        self.num_layers = 4
        self.ff_size = 1024
        self.dropout = 0.1
        self.lstm_layers = 2
        self.bidirectional = True

def get_config(model_name):
    """获取指定模型的配置"""
    config_map = {
        'HMST-DA': HMSTConfig(),
        'MuseMorphose': MuseMorphoseConfig(),
        'MT-LSTM': MTLSTMConfig(),
    }
    return config_map.get(model_name, BaseConfig())