class BaseConfig:
    """
    Base configuration class containing common parameters for all models
    Defines default hyperparameters and training settings
    """
    def __init__(self):
        # General model parameters
        self.batch_size = 16
        self.max_seq_len = 1024        # Maximum sequence length for input
        self.vocab_size = 128          # Vocabulary size for tokenization
        self.input_dim = 128           # Input feature dimension
        self.output_dim = 128          # Output feature dimension
        self.hidden_dim = 512          # Hidden layer dimension
        self.num_layers = 6            # Number of transformer layers
        self.num_heads = 8             # Number of attention heads
        self.dropout = 0.1             # Dropout rate for regularization
        self.learning_rate = 0.0001    # Base learning rate
        
        # Training configuration parameters
        self.train = {
            'batch_size': 16,                    # Training batch size
            'epochs': 100,                       # Maximum training epochs
            'learning_rate': 5e-5,               # Training learning rate
            'early_stopping_patience': 10,       # Early stopping patience
            'max_grad_norm': 0.5                 # Gradient clipping threshold
        }
        
        # Path configuration
        self.save_dir = 'checkpoints'    # Directory for saving model checkpoints
        self.result_dir = 'results'      # Directory for saving results
        self.num_workers = 4             # Number of data loading workers

class HMSTConfig(BaseConfig):
    """
    HMST-DA model specific configuration
    Hierarchical Music Style Transfer with Dual-path Attention
    """
    def __init__(self):
        super().__init__()
        # Model architecture parameters (adjusted to match pre-trained model)
        self.hidden_dim = 256    # Hidden dimension (reduced from 512 to 256)
        self.num_heads = 8       # Number of attention heads
        self.num_layers = 3      # Number of layers (reduced from 6 to 3)
        self.ff_size = 1024      # Feed-forward network size (reduced from 2048 to 1024)
        self.dropout = 0.1       # Dropout rate
        self.style_dim = 256     # Style embedding dimension
        
        # Input/output dimensions (adjusted for MIDI representation)
        self.input_dim = 4       # Input dimension (pitch, start_time, end_time, velocity)
        self.output_dim = 4      # Output dimension (same as input)
        
        # Special mechanism flags
        self.use_dual_attention = True      # Enable dual-path attention mechanism
        self.use_theory_constraints = True  # Enable music theory constraints

class MuseMorphoseConfig(BaseConfig):
    """
    MuseMorphose baseline model configuration
    Encoder-decoder architecture for music style transfer
    """
    def __init__(self):
        super().__init__()
        # Model architecture parameters
        self.hidden_dim = 256    # Hidden dimension
        self.num_heads = 4       # Number of attention heads
        self.num_layers = 4      # Number of transformer layers
        self.ff_size = 1024      # Feed-forward network size
        self.dropout = 0.1       # Dropout rate
        self.style_dim = 128     # Style embedding dimension

class MTLSTMConfig(BaseConfig):
    """
    Music Transformer-LSTM baseline model configuration
    Combines Transformer and LSTM for temporal modeling
    """
    def __init__(self):
        super().__init__()
        # Model architecture parameters
        self.hidden_dim = 256      # Hidden dimension
        self.num_heads = 4         # Number of attention heads
        self.num_layers = 4        # Number of transformer layers
        self.ff_size = 1024        # Feed-forward network size
        self.dropout = 0.1         # Dropout rate
        self.lstm_layers = 2       # Number of LSTM layers
        self.bidirectional = True  # Use bidirectional LSTM

def get_config(model_name):
    """
    Factory function to get configuration for specified model
    Args:
        model_name: Name of the model ('HMST-DA', 'MuseMorphose', 'MT-LSTM')
    Returns:
        Configuration object for the specified model
    """
    config_map = {
        'HMST-DA': HMSTConfig(),
        'MuseMorphose': MuseMorphoseConfig(),
        'MT-LSTM': MTLSTMConfig(),
    }
    return config_map.get(model_name, BaseConfig())