import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Set seaborn style for better visualization
plt.style.use('seaborn-v0_8')  # Use available seaborn style
# Alternative: directly set seaborn style
sns.set_style("whitegrid")

# Read all CSV result files from different experiments
experiments = {
    'Mozart → Chopin': pd.read_csv('results/Mozart_Chopin.csv', index_col=0),
    'Chopin → Liszt': pd.read_csv('results/Chopin_Liszt.csv', index_col=0),
    'Bach → Rachmaninoff': pd.read_csv('results/Bach_Rachmaninoff.csv', index_col=0),
    'Original': pd.read_csv('results/comparison_results_experiment1_20250212_203713.csv', index_col=0)
}

# Set up figure layout as 3 rows, 1 column for better vertical arrangement
fig, axes = plt.subplots(3, 1, figsize=(12, 18))  # Changed to 3x1 layout with taller, narrower dimensions
# fig.suptitle('Comparison of Different Style Transfer Combinations', fontsize=24, y=0.98)  # Adjust main title position

# Define color scheme for consistent visualization
colors = ['#A8D5E5', '#FFB7B2', '#B5EAD7', '#E2F0CB']

# Define metrics and their display titles
metrics = ['style_accuracy', 'content_preservation', 'theory_compliance']
titles = ['Style accuracy', 'Content preservation', 'Theory compliance']

# Create grouped bar charts for each metric
for idx, (metric, title) in enumerate(zip(metrics, titles)):
    # Prepare data for plotting
    data = []
    for exp_name, df in experiments.items():
        data.append(df[metric])
    
    # Create DataFrame for plotting
    df_plot = pd.DataFrame(data, index=experiments.keys())
    
    # Plot bar chart for current metric
    ax = axes[idx]  # Use vertical indexing for 3x1 layout
    df_plot.plot(kind='bar', ax=ax, color=colors, width=0.8, legend=False)  # Remove individual subplot legends
    ax.set_title(title, fontsize=20)  # Increase subplot title font size
    ax.set_ylim(0, 1.1)  # Set y-axis limits from 0 to 1.1
    ax.set_xlabel('', fontsize=20)  # Increase x-axis label font size
    ax.set_ylabel('Score', fontsize=20)  # Increase y-axis label font size
    ax.grid(True, alpha=0.3)  # Add grid with transparency
    
    # Increase tick label font sizes
    ax.tick_params(axis='both', labelsize=20)  # Increase tick label font size
    
    # Rotate x-axis labels for better readability
    ax.tick_params(axis='x', rotation=15)
    
    # Add value labels on top of bars
    for i in ax.containers:
        ax.bar_label(i, 
                    fmt='%.2f',  # Format to 2 decimal places
                    padding=3,   # Padding from bar top
                    fontsize=20, # Increase value label font size
                    label_type='edge')

# Add unified legend at the bottom, adjusted for 3x1 layout
plt.figlegend(['HMST-DA', 'MuseMorphose', 'MT-LSTM', 'Baseline'], 
              loc='lower center',  # Position at bottom center
              bbox_to_anchor=(0.5, -0.02),  # Fine-tune position
              ncol=4,  # Arrange legend items horizontally
              fontsize=20)  # Increase legend font size

# Adjust layout for 3x1 arrangement
plt.tight_layout()
plt.subplots_adjust(bottom=0.1, hspace=0.3)  # Leave space for legend at bottom, adjust row spacing

# Save chart ensuring complete legend is included
plt.savefig('results/combined_comparison.png', bbox_inches='tight', dpi=300)
plt.show()