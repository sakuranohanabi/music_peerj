import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 设置seaborn样式
plt.style.use('seaborn-v0_8')  # 或者使用其他可用的样式
# 或者直接使用
sns.set_style("whitegrid")

# 读取所有CSV文件
experiments = {
    'Mozart → Chopin': pd.read_csv('results/Mozart_Chopin.csv', index_col=0),
    'Chopin → Liszt': pd.read_csv('results/Chopin_Liszt.csv', index_col=0),
    'Bach → Rachmaninoff': pd.read_csv('results/Bach_Rachmaninoff.csv', index_col=0),
    'Original': pd.read_csv('results/comparison_results_experiment1_20250212_203713.csv', index_col=0)
}

# 设置图表风格，增加整体宽度
fig, axes = plt.subplots(1, 3, figsize=(24, 6))  # 增加宽度从20到24
fig.suptitle('Comparison of Different Style Transfer Combinations', fontsize=16, y=1.05)

# 设置颜色方案
colors = ['#A8D5E5', '#FFB7B2', '#B5EAD7', '#E2F0CB']
metrics = ['style_accuracy', 'content_preservation', 'theory_compliance']
titles = ['Style accuracy', 'Content preservation', 'Theory compliance']

# 为每个指标创建分组柱状图
for idx, (metric, title) in enumerate(zip(metrics, titles)):
    data = []
    for exp_name, df in experiments.items():
        data.append(df[metric])
    
    df_plot = pd.DataFrame(data, index=experiments.keys())
    
    ax = axes[idx]
    df_plot.plot(kind='bar', ax=ax, color=colors, width=0.8)
    ax.set_title(title, fontsize=14)  # 增大标题字体
    ax.set_ylim(0, 1.1)
    ax.set_xlabel('', fontsize=12)  # 增大x轴标签字体
    ax.set_ylabel('Score', fontsize=12)  # 增大y轴标签字体
    ax.grid(True, alpha=0.3)
    
    # 增大刻度标签字体
    ax.tick_params(axis='both', labelsize=10)  # 同时设置x轴和y轴的刻度标签大小
    
    # 旋转x轴标签
    ax.tick_params(axis='x', rotation=20)
    
    # 添加数值标签
    for i in ax.containers:
        ax.bar_label(i, 
                    fmt='%.2f', 
                    padding=3,
                    fontsize=8,  # 减小字体大小  # 垂直显示数字
                    label_type='edge')

# 添加统一图例，调整位置到更右侧
plt.figlegend(['HMST-DA', 'MuseMorphose', 'MT-LSTM', 'Baseline'], 
              loc='center right', 
            #   bbox_to_anchor=(1.18, 0.5),
              fontsize=1)  # 将x值从1.12增加到1.18

# 调整布局，增加右边距
# plt.tight_layout(rect=[0, 0, 0.95, 1])  # 添加rect参数来控制图表区域

# 保存图表，确保包含完整的图例
plt.savefig('results/combined_comparison.png', bbox_inches='tight', dpi=300)
plt.show()