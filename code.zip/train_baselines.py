import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from tqdm import tqdm
import os
from pathlib import Path

# 导入配置和模型
from config import Config
from compare import MuseMorphose, MusicTransformerLSTM
from dataset import MusicDataset

def train_model(model_name, model, train_loader, val_loader, config, device):
    """训练基线模型"""
    print(f"\nTraining {model_name}...")
    
    # 设置优化器和损失函数
    optimizer = optim.AdamW(
        model.parameters(),
        lr=config.train['learning_rate'],
        weight_decay=config.optimizer['weight_decay'],
        betas=(config.optimizer['beta1'], config.optimizer['beta2'])
    )
    
    # 使用配置中的学习率调度器
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode='min',
        factor=config.optimizer['scheduler_factor'],
        patience=config.optimizer['scheduler_patience'],
        threshold=config.optimizer['scheduler_threshold'],
        cooldown=config.optimizer['scheduler_cooldown'],
        min_lr=config.optimizer['scheduler_min_lr']
    )
    
    criterion = nn.MSELoss()
    
    # 创建检查点目录
    checkpoint_dir = Path(config.save_dir)
    checkpoint_dir.mkdir(exist_ok=True)
    
    best_val_loss = float('inf')
    patience_counter = 0
    
    for epoch in range(config.train['epochs']):
        # 训练阶段
        model.train()
        train_loss = 0
        train_batches = 0
        
        progress_bar = tqdm(train_loader, desc=f"Epoch {epoch+1}/{config.train['epochs']}")
        for batch in progress_bar:
            source, target_style, target = batch
            source = source.to(device)
            target_style = target_style.to(device)
            target = target.to(device)
            
            optimizer.zero_grad()
            output = model(source, target_style)
            loss = criterion(output, target)
            loss.backward()
            
            # 梯度裁剪
            torch.nn.utils.clip_grad_norm_(
                model.parameters(), 
                config.train['max_grad_norm']
            )
            
            optimizer.step()
            
            train_loss += loss.item()
            train_batches += 1
            
            # 更新进度条
            progress_bar.set_postfix({'loss': f"{loss.item():.4f}"})
        
        avg_train_loss = train_loss / train_batches
        
        # 验证阶段
        model.eval()
        val_loss = 0
        val_batches = 0
        
        with torch.no_grad():
            for batch in val_loader:
                source, target_style, target = batch
                source = source.to(device)
                target_style = target_style.to(device)
                target = target.to(device)
                
                output = model(source, target_style)
                loss = criterion(output, target)
                
                val_loss += loss.item()
                val_batches += 1
        
        avg_val_loss = val_loss / val_batches
        
        print(f"Epoch {epoch+1}: Train Loss = {avg_train_loss:.4f}, Val Loss = {avg_val_loss:.4f}")
        
        # 更新学习率
        scheduler.step(avg_val_loss)
        
        # 保存最佳模型
        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            patience_counter = 0
            checkpoint_path = checkpoint_dir / f"{model_name.lower()}.pth"
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
                'loss': best_val_loss,
            }, checkpoint_path)
            print(f"Saved best model with validation loss: {best_val_loss:.4f}")
        else:
            patience_counter += 1
            
        # 早停
        if patience_counter >= config.train['early_stopping_patience']:
            print(f"Early stopping after {epoch+1} epochs")
            break

def main():
    # 加载配置
    config = Config()
    
    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    # 创建数据集
    train_dataset = MusicDataset(config, split='train')
    val_dataset = MusicDataset(config, split='val')
    
    # 创建数据加载器
    train_loader = DataLoader(
        train_dataset,
        batch_size=config.train['batch_size'],
        shuffle=True,
        num_workers=config.num_workers,
        pin_memory=True
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=config.train['batch_size'],
        shuffle=False,
        num_workers=config.num_workers,
        pin_memory=True
    )
    
    # 训练 MuseMorphose
    print("\nInitializing MuseMorphose model...")
    muse_model = MuseMorphose(config).to(device)
    train_model('MuseMorphose', muse_model, train_loader, val_loader, config, device)
    
    # 训练 MT-LSTM
    print("\nInitializing MT-LSTM model...")
    lstm_model = MusicTransformerLSTM(config).to(device)
    train_model('MT-LSTM', lstm_model, train_loader, val_loader, config, device)

if __name__ == "__main__":
    main()