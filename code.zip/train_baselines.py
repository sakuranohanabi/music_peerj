import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from tqdm import tqdm
import os
from pathlib import Path

# Import configuration and models
from config import Config
from compare import MuseMorphose, MusicTransformerLSTM
from dataset import MusicDataset

def train_model(model_name, model, train_loader, val_loader, config, device):
    """
    Train a baseline model with comprehensive training loop
    
    Args:
        model_name: Name of the model being trained
        model: Model instance to train
        train_loader: DataLoader for training data
        val_loader: DataLoader for validation data
        config: Configuration object with training parameters
        device: Computing device (CPU/GPU)
    """
    print(f"\nTraining {model_name}...")
    
    # Set up optimizer with AdamW for better weight decay handling
    optimizer = optim.AdamW(
        model.parameters(),
        lr=config.train['learning_rate'],
        weight_decay=config.optimizer['weight_decay'],
        betas=(config.optimizer['beta1'], config.optimizer['beta2'])
    )
    
    # Configure learning rate scheduler from config parameters
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode='min',                                          # Reduce when validation loss plateaus
        factor=config.optimizer['scheduler_factor'],         # Multiply LR by this factor
        patience=config.optimizer['scheduler_patience'],     # Wait this many epochs
        threshold=config.optimizer['scheduler_threshold'],   # Minimum change to qualify as improvement
        cooldown=config.optimizer['scheduler_cooldown'],     # Cooldown period after LR reduction
        min_lr=config.optimizer['scheduler_min_lr']          # Minimum learning rate
    )
    
    # Use Mean Squared Error loss for music generation tasks
    criterion = nn.MSELoss()
    
    # Create checkpoint directory for saving model states
    checkpoint_dir = Path(config.save_dir)
    checkpoint_dir.mkdir(exist_ok=True)
    
    # Initialize training monitoring variables
    best_val_loss = float('inf')
    patience_counter = 0
    
    # Main training loop over specified epochs
    for epoch in range(config.train['epochs']):
        # Training phase
        model.train()
        train_loss = 0
        train_batches = 0
        
        # Progress bar for training monitoring
        progress_bar = tqdm(train_loader, desc=f"Epoch {epoch+1}/{config.train['epochs']}")
        for batch in progress_bar:
            source, target_style, target = batch
            # Move data to computing device
            source = source.to(device)
            target_style = target_style.to(device)
            target = target.to(device)
            
            # Reset gradients
            optimizer.zero_grad()
            
            # Forward pass through the model
            output = model(source, target_style)
            
            # Compute loss
            loss = criterion(output, target)
            
            # Backward pass
            loss.backward()
            
            # Apply gradient clipping to prevent exploding gradients
            torch.nn.utils.clip_grad_norm_(
                model.parameters(), 
                config.train['max_grad_norm']
            )
            
            # Update model parameters
            optimizer.step()
            
            # Accumulate training statistics
            train_loss += loss.item()
            train_batches += 1
            
            # Update progress bar with current loss
            progress_bar.set_postfix({'loss': f"{loss.item():.4f}"})
        
        # Calculate average training loss for the epoch
        avg_train_loss = train_loss / train_batches
        
        # Validation phase
        model.eval()
        val_loss = 0
        val_batches = 0
        
        # Disable gradient computation for validation
        with torch.no_grad():
            for batch in val_loader:
                source, target_style, target = batch
                # Move validation data to device
                source = source.to(device)
                target_style = target_style.to(device)
                target = target.to(device)
                
                # Forward pass for validation
                output = model(source, target_style)
                loss = criterion(output, target)
                
                # Accumulate validation statistics
                val_loss += loss.item()
                val_batches += 1
        
        # Calculate average validation loss
        avg_val_loss = val_loss / val_batches
        
        # Print epoch results
        print(f"Epoch {epoch+1}: Train Loss = {avg_train_loss:.4f}, Val Loss = {avg_val_loss:.4f}")
        
        # Update learning rate based on validation performance
        scheduler.step(avg_val_loss)
        
        # Model checkpointing - save best model based on validation performance
        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            patience_counter = 0  # Reset patience counter
            
            # Save model checkpoint with all necessary information
            checkpoint_path = checkpoint_dir / f"{model_name.lower()}.pth"
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
                'loss': best_val_loss,
            }, checkpoint_path)
            print(f"Saved best model with validation loss: {best_val_loss:.4f}")
        else:
            patience_counter += 1
            
        # Early stopping mechanism to prevent overfitting
        if patience_counter >= config.train['early_stopping_patience']:
            print(f"Early stopping after {epoch+1} epochs")
            break

def main():
    """
    Main function to train all baseline models
    """
    # Load configuration for baseline training
    config = Config()
    
    # Set computing device (GPU if available, otherwise CPU)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    # Create datasets for training and validation
    train_dataset = MusicDataset(config, split='train')
    val_dataset = MusicDataset(config, split='val')
    
    # Create data loaders with appropriate batch size and workers
    train_loader = DataLoader(
        train_dataset,
        batch_size=config.train['batch_size'],
        shuffle=True,                    # Shuffle training data for better generalization
        num_workers=config.num_workers,  # Parallel data loading
        pin_memory=True                  # Faster GPU transfer
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=config.train['batch_size'],
        shuffle=False,                   # No need to shuffle validation data
        num_workers=config.num_workers,
        pin_memory=True
    )
    
    # Train MuseMorphose baseline model
    print("\nInitializing MuseMorphose model...")
    muse_model = MuseMorphose(config).to(device)
    train_model('MuseMorphose', muse_model, train_loader, val_loader, config, device)
    
    # Train MT-LSTM baseline model
    print("\nInitializing MT-LSTM model...")
    lstm_model = MusicTransformerLSTM(config).to(device)
    train_model('MT-LSTM', lstm_model, train_loader, val_loader, config, device)

if __name__ == "__main__":
    # Execute main function when script is run directly
    main()