import torch
from torch.utils.data import Dataset
import numpy as np
from pathlib import Path
import music21
import os
import json
import pandas as pd

class MusicDataset(Dataset):
    def __init__(self, config, split='train'):
        self.config = config
        
        # MAESTRO数据集路径
        self.data_path = Path('D:/Files/Code/MusicResearch/music/maestro-v3.0.0')
        
        # 加载MAESTRO的CSV文件
        csv_path = self.data_path / 'maestro-v3.0.0.csv'
        print(f"Loading metadata from {csv_path}")
        
        # 读取CSV文件
        df = pd.read_csv(csv_path)
        
        # 筛选Bach和Chopin的作品
        # bach_df = df[df['canonical_composer'].str.contains('Bach', case=False, na=False)]
        # chopin_df = df[df['canonical_composer'].str.contains('Chopin', case=False, na=False)]
        
        # bach_df = df[df['canonical_composer'].str.contains('Mozart', case=False, na=False)]
        # chopin_df = df[df['canonical_composer'].str.contains('Chopin', case=False, na=False)]

        bach_df = df[df['canonical_composer'].str.contains('Bach', case=False, na=False)]
        chopin_df = df[df['canonical_composer'].str.contains('Rachmaninoff', case=False, na=False)]

        # bach_df = df[df['canonical_composer'].str.contains('Alexander', case=False, na=False)]
        # chopin_df = df[df['canonical_composer'].str.contains('Beethoven', case=False, na=False)]

        print(f"Found {len(bach_df)} Bach pieces and {len(chopin_df)} Chopin pieces")
        
        # 根据split划分数据
        source_train_size = int(len(bach_df) * 0.8)
        target_train_size = int(len(chopin_df) * 0.8)

        if split == 'train':
            self.source_files = bach_df.iloc[:source_train_size]
            self.target_files = chopin_df.iloc[:target_train_size]
        elif split == 'val':
            self.source_files = bach_df.iloc[source_train_size:source_train_size+int(len(bach_df)*0.1)]
            self.target_files = chopin_df.iloc[target_train_size:target_train_size+int(len(chopin_df)*0.1)]
        else:  # test
            self.source_files = bach_df.iloc[source_train_size+int(len(bach_df)*0.1):]
            self.target_files = chopin_df.iloc[target_train_size+int(len(chopin_df)*0.1):]
        
        # 转换为文件路径列表
        self.source_files = [self.data_path / f for f in self.source_files['midi_filename']]
        self.target_files = [self.data_path / f for f in self.target_files['midi_filename']]
        
        # 打印更详细的信息
        print(f"Total {split} data:")
        print(f"  Source: {len(bach_df)} pieces")
        print(f"  Target: {len(chopin_df)} pieces")
        print(f"After split {split}:")
        print(f"  Source: {len(self.source_files)} files")
        print(f"  Target: {len(self.target_files)} files")
        
        if len(self.source_files) == 0 or len(self.target_files) == 0:
            raise ValueError(f"No data found for {split} split!")
    
    def __len__(self):
        return len(self.source_files)
    
    def __getitem__(self, idx):
        # 加载源文件（Bach）和目标文件（Chopin）
        source_path = self.source_files[idx]
        target_idx = idx % len(self.target_files)  # 循环使用目标文件
        target_path = self.target_files[target_idx]
        
        # 转换为tensor
        source = self.load_midi(source_path)
        target = self.load_midi(target_path)
        
        # 确保序列长度一致
        max_len = 512
        if source.size(0) > max_len:
            start = np.random.randint(0, source.size(0) - max_len)
            source = source[start:start + max_len]
        else:
            pad_len = max_len - source.size(0)
            source = torch.nn.functional.pad(source, (0, 0, 0, pad_len))
            
        if target.size(0) > max_len:
            start = np.random.randint(0, target.size(0) - max_len)
            target = target[start:start + max_len]
        else:
            pad_len = max_len - target.size(0)
            target = torch.nn.functional.pad(target, (0, 0, 0, pad_len))
        
        return source, target, target
    
    def load_midi(self, path):
        """加载MIDI文件并转换为tensor"""
        try:
            midi = music21.converter.parse(str(path))
            features = self.extract_features(midi)
            return torch.FloatTensor(features)
        except Exception as e:
            print(f"Error loading {path}: {e}")
            return torch.zeros((512, 4))  # [sequence_length, feature_dim]
    
    def extract_features(self, midi):
        """从MIDI文件提取特征"""
        features = []
        for note in midi.flat.notes:
            if not hasattr(note, 'pitch'):
                continue
                
            # 提取特征
            velocity = note.volume.velocity if hasattr(note, 'volume') else 80
            velocity = max(min(velocity, 100), 40)  # 限制在40-100之间
            
            feature = [
                note.pitch.midi / 127.0,  # 音高
                note.offset / 100.0,      # 开始时间
                note.duration.quarterLength / 4.0,  # 持续时间
                velocity / 127.0  # 力度
            ]
            features.append(feature)
        
        if not features:
            return np.zeros((512, 4))
            
        features = np.array(features)
        
        # 如果特征数量超过最大限制，进行随机采样
        if len(features) > 512:
            indices = np.random.choice(len(features), 512, replace=False)
            features = features[indices]
        elif len(features) < 512:
            # 填充到固定长度
            pad_length = 512 - len(features)
            padding = np.zeros((pad_length, 4))
            features = np.vstack([features, padding])
        
        return features