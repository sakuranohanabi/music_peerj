import torch
from torch.utils.data import Dataset
import numpy as np
from pathlib import Path
import music21
import os
import json
import pandas as pd

class MusicDataset(Dataset):
    """
    MAESTRO Music Dataset for Style Transfer
    Loads and preprocesses MIDI files from the MAESTRO dataset for music style transfer tasks
    """
    def __init__(self, config, split='train'):
        """
        Initialize the music dataset
        Args:
            config: Configuration object containing dataset parameters
            split: Dataset split ('train', 'val', or 'test')
        """
        self.config = config
        
        # MAESTRO dataset path
        self.data_path = Path('D:/Files/Code/MusicResearch/music/maestro-v3.0.0')
        
        # Load MAESTRO CSV metadata file
        csv_path = self.data_path / 'maestro-v3.0.0.csv'
        print(f"Loading metadata from {csv_path}")
        
        # Read CSV file containing metadata
        df = pd.read_csv(csv_path)
        
        # Filter works by specific composers for style transfer
        # Currently configured for Bach -> Rachmaninoff style transfer
        # bach_df = df[df['canonical_composer'].str.contains('Bach', case=False, na=False)]
        # chopin_df = df[df['canonical_composer'].str.contains('Chopin', case=False, na=False)]
        
        # Alternative composer combinations (commented out)
        # bach_df = df[df['canonical_composer'].str.contains('Mozart', case=False, na=False)]
        # chopin_df = df[df['canonical_composer'].str.contains('Chopin', case=False, na=False)]

        bach_df = df[df['canonical_composer'].str.contains('Bach', case=False, na=False)]
        chopin_df = df[df['canonical_composer'].str.contains('Rachmaninoff', case=False, na=False)]

        # bach_df = df[df['canonical_composer'].str.contains('Alexander', case=False, na=False)]
        # chopin_df = df[df['canonical_composer'].str.contains('Beethoven', case=False, na=False)]

        print(f"Found {len(bach_df)} Bach pieces and {len(chopin_df)} Chopin pieces")
        
        # Split data according to specified split ratio (80% train, 10% val, 10% test)
        source_train_size = int(len(bach_df) * 0.8)
        target_train_size = int(len(chopin_df) * 0.8)

        if split == 'train':
            # Training split: first 80% of each composer's works
            self.source_files = bach_df.iloc[:source_train_size]
            self.target_files = chopin_df.iloc[:target_train_size]
        elif split == 'val':
            # Validation split: next 10% of each composer's works
            self.source_files = bach_df.iloc[source_train_size:source_train_size+int(len(bach_df)*0.1)]
            self.target_files = chopin_df.iloc[target_train_size:target_train_size+int(len(chopin_df)*0.1)]
        else:  # test
            # Test split: remaining 10% of each composer's works
            self.source_files = bach_df.iloc[source_train_size+int(len(bach_df)*0.1):]
            self.target_files = chopin_df.iloc[target_train_size+int(len(chopin_df)*0.1):]
        
        # Convert DataFrame rows to file path lists
        self.source_files = [self.data_path / f for f in self.source_files['midi_filename']]
        self.target_files = [self.data_path / f for f in self.target_files['midi_filename']]
        
        # Print detailed information about the dataset split
        print(f"Total {split} data:")
        print(f"  Source: {len(bach_df)} pieces")
        print(f"  Target: {len(chopin_df)} pieces")
        print(f"After split {split}:")
        print(f"  Source: {len(self.source_files)} files")
        print(f"  Target: {len(self.target_files)} files")
        
        # Validate that we have data for the specified split
        if len(self.source_files) == 0 or len(self.target_files) == 0:
            raise ValueError(f"No data found for {split} split!")
    
    def __len__(self):
        """Return the size of the dataset (number of source files)"""
        return len(self.source_files)
    
    def __getitem__(self, idx):
        """
        Get a single data sample
        Args:
            idx: Index of the sample to retrieve
        Returns:
            Tuple of (source_tensor, target_tensor, target_tensor)
            - source_tensor: Source style music (e.g., Bach)
            - target_tensor: Target style music (e.g., Rachmaninoff) 
            - Third element is duplicate of target for compatibility
        """
        # Load source file (Bach) and target file (Rachmaninoff)
        source_path = self.source_files[idx]
        target_idx = idx % len(self.target_files)  # Cycle through target files if fewer than source
        target_path = self.target_files[target_idx]
        
        # Convert MIDI files to tensor representation
        source = self.load_midi(source_path)
        target = self.load_midi(target_path)
        
        # Ensure consistent sequence length across samples
        max_len = 512  # Fixed sequence length
        
        # Truncate or pad source sequence to max_len
        if source.size(0) > max_len:
            # Randomly crop if sequence is too long
            start = np.random.randint(0, source.size(0) - max_len)
            source = source[start:start + max_len]
        else:
            # Pad with zeros if sequence is too short
            pad_len = max_len - source.size(0)
            source = torch.nn.functional.pad(source, (0, 0, 0, pad_len))
            
        # Truncate or pad target sequence to max_len
        if target.size(0) > max_len:
            # Randomly crop if sequence is too long
            start = np.random.randint(0, target.size(0) - max_len)
            target = target[start:start + max_len]
        else:
            # Pad with zeros if sequence is too short
            pad_len = max_len - target.size(0)
            target = torch.nn.functional.pad(target, (0, 0, 0, pad_len))
        
        return source, target, target
    
    def load_midi(self, path):
        """
        Load MIDI file and convert to tensor representation
        Args:
            path: Path to the MIDI file
        Returns:
            Tensor representation of the MIDI file [sequence_length, feature_dim]
        """
        try:
            # Parse MIDI file using music21
            midi = music21.converter.parse(str(path))
            # Extract musical features from the parsed MIDI
            features = self.extract_features(midi)
            return torch.FloatTensor(features)
        except Exception as e:
            print(f"Error loading {path}: {e}")
            # Return zero tensor if loading fails
            return torch.zeros((512, 4))  # [sequence_length, feature_dim]
    
    def extract_features(self, midi):
        """
        Extract musical features from MIDI file
        Args:
            midi: Parsed MIDI object from music21
        Returns:
            NumPy array of musical features [num_notes, 4]
            Features: [pitch, start_time, duration, velocity]
        """
        features = []
        
        # Iterate through all notes in the MIDI file
        for note in midi.flat.notes:
            # Skip elements that don't have pitch information
            if not hasattr(note, 'pitch'):
                continue
                
            # Extract velocity (volume) information
            velocity = note.volume.velocity if hasattr(note, 'volume') else 80
            velocity = max(min(velocity, 100), 40)  # Clamp velocity to reasonable range (40-100)
            
            # Create feature vector for this note
            feature = [
                note.pitch.midi / 127.0,              # Normalized pitch (0-1)
                note.offset / 100.0,                  # Normalized start time
                note.duration.quarterLength / 4.0,    # Normalized duration
                velocity / 127.0                      # Normalized velocity (0-1)
            ]
            features.append(feature)
        
        # Handle empty MIDI files
        if not features:
            return np.zeros((512, 4))
            
        features = np.array(features)
        
        # Handle sequence length normalization
        if len(features) > 512:
            # Randomly sample 512 notes if too many
            indices = np.random.choice(len(features), 512, replace=False)
            features = features[indices]
        elif len(features) < 512:
            # Pad with zeros if too few notes
            pad_length = 512 - len(features)
            padding = np.zeros((pad_length, 4))
            features = np.vstack([features, padding])
        
        return features